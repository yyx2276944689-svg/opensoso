from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QTextEdit, QPushButton,
                            QFileDialog, QMessageBox, QHBoxLayout, QCheckBox,
                            QLineEdit, QWidget)
import os
import json
from PyQt6.QtGui import QIcon

# 配置文件路径
GETNAME_CONFIG_FILE = "getname_config.json"

def load_getname_config():
    """加载获取文件名功能的配置"""
    if os.path.exists(GETNAME_CONFIG_FILE):
        try:
            with open(GETNAME_CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            pass
    return {
        "last_folder_path": "",
        "show_suffix": True,
        "selected_types": []
    }

def save_getname_config(config):
    """保存获取文件名功能的配置"""
    try:
        with open(GETNAME_CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"保存配置失败: {e}")

class GetNameWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("获取文件夹所有文件名")
        self.setMinimumSize(600, 500)
        self.setStyleSheet("""
            QDialog {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
                min-height: 30px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QLineEdit {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
                font-size: 14px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            QTextEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
                font-size: 14px;
            }
            QCheckBox {
                font-size: 14px;
                color: #333;
                padding: 5px;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 设置窗口图标
        icon_path = os.path.join(os.path.dirname(__file__), "getname.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        # 加载配置
        self.config = load_getname_config()

        # 初始化变量
        self.folder_path = ""
        self.filenames = []
        self.suffixes = []
        self.type_checkboxes = []

        # 文件夹选择区域
        folder_layout = QHBoxLayout()
        folder_layout.addWidget(QLabel("选择文件夹:"))

        self.folder_entry = QLineEdit()
        self.folder_entry.setPlaceholderText("请选择要获取文件名的文件夹...")
        self.folder_entry.setReadOnly(True)
        folder_layout.addWidget(self.folder_entry)

        self.select_folder_btn = QPushButton("浏览")
        self.select_folder_btn.clicked.connect(self.select_folder)
        folder_layout.addWidget(self.select_folder_btn)

        layout.addLayout(folder_layout)

        # 文件类型选择区域（初始隐藏）
        self.type_frame = QWidget()
        self.type_layout = QVBoxLayout(self.type_frame)
        self.type_layout.setContentsMargins(0, 0, 0, 0)

        # 类型标签
        type_label = QLabel("选择文件类型:")
        self.type_layout.addWidget(type_label)

        # 类型复选框容器
        self.type_checkboxes_layout = QHBoxLayout()
        self.type_layout.addLayout(self.type_checkboxes_layout)

        # 显示后缀选项
        self.show_suffix_cb = QCheckBox("显示文件后缀")
        self.show_suffix_cb.setChecked(self.config.get("show_suffix", True))
        self.show_suffix_cb.stateChanged.connect(self.update_display)
        self.show_suffix_cb.stateChanged.connect(self.save_config)  # 保存配置
        self.type_layout.addWidget(self.show_suffix_cb)

        self.type_frame.setVisible(False)  # 初始隐藏
        layout.addWidget(self.type_frame)

        # 文件名显示区域
        display_label = QLabel("文件名列表:")
        layout.addWidget(display_label)

        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(False)
        self.text_edit.setPlaceholderText("请先选择文件夹...")
        layout.addWidget(self.text_edit)

        # 按钮区域
        button_layout = QHBoxLayout()

        self.refresh_btn = QPushButton("刷新文件列表")
        self.refresh_btn.clicked.connect(self.refresh_files)
        self.refresh_btn.setEnabled(False)
        button_layout.addWidget(self.refresh_btn)

        self.copy_btn = QPushButton("复制全部文件名")
        self.copy_btn.clicked.connect(self.copy_names)
        self.copy_btn.setEnabled(False)
        button_layout.addWidget(self.copy_btn)

        layout.addLayout(button_layout)

        # 自动加载上次的文件夹路径
        self.load_last_folder()

    def load_last_folder(self):
        """加载上次选择的文件夹"""
        last_folder = self.config.get("last_folder_path", "")
        if last_folder and os.path.exists(last_folder):
            self.folder_path = last_folder
            self.folder_entry.setText(last_folder)
            self.load_files()
        else:
            # 如果上次的路径不存在，清空配置中的路径
            if last_folder:
                self.config["last_folder_path"] = ""
                self.save_config()

    def save_config(self):
        """保存当前配置"""
        try:
            # 检查基本属性是否存在
            if not hasattr(self, 'config') or not hasattr(self, 'folder_path'):
                return

            self.config["last_folder_path"] = self.folder_path

            # 安全地获取显示后缀选项
            if hasattr(self, 'show_suffix_cb') and self.show_suffix_cb:
                try:
                    self.config["show_suffix"] = self.show_suffix_cb.isChecked()
                except RuntimeError:
                    # 控件已被删除，跳过
                    pass

            # 保存选中的文件类型
            selected_types = []
            if hasattr(self, 'type_checkboxes'):
                for cb in self.type_checkboxes:
                    try:
                        if cb.isChecked():
                            selected_types.append(cb.text())
                    except RuntimeError:
                        # 控件已被删除，跳过
                        continue
                    except:
                        # 其他错误，跳过
                        continue
            self.config["selected_types"] = selected_types

            save_getname_config(self.config)
        except Exception as e:
            # 静默处理保存错误，避免影响用户体验
            print(f"保存配置时出错: {e}")

    def select_folder(self):
        """选择文件夹"""
        # 使用上次的路径作为起始目录
        start_dir = self.folder_path if self.folder_path and os.path.exists(self.folder_path) else ""
        folder_path = QFileDialog.getExistingDirectory(self, "选择文件夹", start_dir)
        if folder_path:
            self.folder_path = folder_path
            self.folder_entry.setText(folder_path)
            self.load_files()
            # 保存新选择的路径
            self.save_config()

    def load_files(self):
        """加载文件列表"""
        # 检查窗口是否仍然有效
        if not hasattr(self, 'folder_path') or not self.folder_path:
            return

        if not os.path.exists(self.folder_path):
            try:
                QMessageBox.warning(self, "警告", "文件夹路径无效！")
            except RuntimeError:
                # 窗口已被删除，直接返回
                return
            return

        try:
            # 检查关键组件是否仍然存在
            if not hasattr(self, 'type_checkboxes_layout') or self.type_checkboxes_layout is None:
                return

            # 获取所有文件名
            self.filenames = [f for f in os.listdir(self.folder_path)
                            if os.path.isfile(os.path.join(self.folder_path, f))]

            if not self.filenames:
                try:
                    QMessageBox.information(self, "提示", "该文件夹中没有文件！")
                    if hasattr(self, 'text_edit') and self.text_edit:
                        self.text_edit.setPlaceholderText("该文件夹中没有文件...")
                        self.text_edit.clear()
                    if hasattr(self, 'type_frame') and self.type_frame:
                        self.type_frame.setVisible(False)
                    if hasattr(self, 'refresh_btn') and self.refresh_btn:
                        self.refresh_btn.setEnabled(False)
                    if hasattr(self, 'copy_btn') and self.copy_btn:
                        self.copy_btn.setEnabled(False)
                except RuntimeError:
                    # 窗口已被删除，直接返回
                    return
                return

            # 统计所有文件类型
            self.suffixes = set()
            for f in self.filenames:
                _, ext = os.path.splitext(f)
                if ext:
                    self.suffixes.add(ext.lower())
                else:
                    self.suffixes.add('(无后缀)')
            self.suffixes = sorted(self.suffixes)

            # 清除旧的类型复选框
            self.clear_type_checkboxes()

            # 再次检查布局是否仍然有效
            if not hasattr(self, 'type_checkboxes_layout') or self.type_checkboxes_layout is None:
                return

            # 创建新的类型复选框
            self.type_checkboxes = []
            saved_selected_types = self.config.get("selected_types", [])

            for suf in self.suffixes:
                try:
                    cb = QCheckBox(suf)
                    # 如果有保存的选择状态，使用保存的状态；否则默认全选
                    if saved_selected_types:
                        cb.setChecked(suf in saved_selected_types)
                    else:
                        cb.setChecked(True)
                    cb.stateChanged.connect(self.update_display)
                    cb.stateChanged.connect(self.save_config)  # 保存配置
                    self.type_checkboxes.append(cb)

                    # 添加到布局
                    self.type_checkboxes_layout.addWidget(cb)
                except RuntimeError:
                    # 窗口已被删除，停止创建更多控件
                    break
                except Exception as e:
                    print(f"创建复选框失败: {e}")
                    break

            # 显示类型选择区域和启用按钮
            try:
                if hasattr(self, 'type_frame') and self.type_frame:
                    self.type_frame.setVisible(True)
                if hasattr(self, 'refresh_btn') and self.refresh_btn:
                    self.refresh_btn.setEnabled(True)
                if hasattr(self, 'copy_btn') and self.copy_btn:
                    self.copy_btn.setEnabled(True)

                # 更新显示
                self.update_display()
            except RuntimeError:
                # 窗口已被删除，直接返回
                return

        except Exception as e:
            try:
                QMessageBox.critical(self, "错误", f"读取文件夹失败：{str(e)}")
            except RuntimeError:
                # 窗口已被删除，静默处理错误
                print(f"GetNameWindow: 读取文件夹失败：{str(e)}")

    def clear_type_checkboxes(self):
        """清除所有类型复选框"""
        if not hasattr(self, 'type_checkboxes'):
            return

        for cb in self.type_checkboxes:
            try:
                # 先断开信号连接，避免在删除过程中触发信号
                cb.stateChanged.disconnect()
            except:
                pass

            try:
                # 从布局中移除控件
                if (hasattr(self, 'type_checkboxes_layout') and
                    self.type_checkboxes_layout is not None):
                    self.type_checkboxes_layout.removeWidget(cb)
            except RuntimeError:
                # 布局已被删除，跳过
                pass
            except:
                pass

            try:
                # 删除控件
                cb.deleteLater()
            except RuntimeError:
                # 控件已被删除，跳过
                pass
            except:
                pass

        self.type_checkboxes.clear()

    def refresh_files(self):
        """刷新文件列表"""
        if self.folder_path:
            self.load_files()
        else:
            QMessageBox.warning(self, "警告", "请先选择文件夹！")

    def update_display(self):
        """更新文件名显示"""
        try:
            # 检查窗口是否仍然有效
            if not hasattr(self, 'filenames') or not self.filenames:
                return

            # 检查关键组件是否仍然存在
            if not hasattr(self, 'type_checkboxes'):
                return

            # 获取选中的类型
            checked_types = set()
            for cb in self.type_checkboxes:
                try:
                    if cb.isChecked():
                        checked_types.add(cb.text())
                except RuntimeError:
                    # 控件已被删除，跳过
                    continue
                except:
                    # 其他错误，跳过
                    continue

            if not checked_types:
                try:
                    if hasattr(self, 'text_edit') and self.text_edit:
                        self.text_edit.setText("请至少选择一种文件类型")
                except RuntimeError:
                    # 窗口已被删除，直接返回
                    return
                return

            # 安全地获取显示后缀选项
            show_suffix = True  # 默认值
            if hasattr(self, 'show_suffix_cb') and self.show_suffix_cb:
                try:
                    show_suffix = self.show_suffix_cb.isChecked()
                except RuntimeError:
                    # 控件已被删除，使用默认值
                    pass
                except:
                    pass

            display_names = []

            for f in self.filenames:
                name, ext = os.path.splitext(f)
                ext_label = ext.lower() if ext else '(无后缀)'

                if ext_label in checked_types:
                    if show_suffix or ext_label == '(无后缀)':
                        display_names.append(f)
                    else:
                        display_names.append(name)

            # 按文件名排序
            display_names.sort()

            # 更新显示
            try:
                if hasattr(self, 'text_edit') and self.text_edit:
                    self.text_edit.setText("\n".join(display_names))
            except RuntimeError:
                # 窗口已被删除，直接返回
                return

            # 更新窗口标题显示文件数量
            try:
                self.setWindowTitle(f"获取文件夹所有文件名 - 共 {len(display_names)} 个文件")
            except RuntimeError:
                # 窗口已被删除，跳过
                pass
            except:
                pass

        except Exception as e:
            # 静默处理更新错误，避免崩溃
            print(f"更新显示时出错: {e}")

    def copy_names(self):
        """复制文件名到剪贴板"""
        text = self.text_edit.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "警告", "没有可复制的文件名！")
            return

        try:
            from PyQt6.QtWidgets import QApplication
            clipboard = QApplication.clipboard()
            clipboard.setText(text)

            # 统计复制的文件数量
            file_count = len(text.split('\n')) if text else 0
            QMessageBox.information(self, "复制成功", f"已复制 {file_count} 个文件名到剪贴板！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"复制失败：{str(e)}")

    def closeEvent(self, event):
        """窗口关闭事件"""
        try:
            # 保存配置
            self.save_config()
        except:
            pass

        try:
            # 清理资源
            self.clear_type_checkboxes()
        except:
            pass

        # 确保接受关闭事件
        event.accept()

