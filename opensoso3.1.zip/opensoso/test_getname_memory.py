#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试获取文件名功能的路径记忆
"""

import sys
import os
import json
from PyQt6.QtWidgets import QApplication

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from getname import GetNameWindow, load_getname_config, save_getname_config, GETNAME_CONFIG_FILE

def create_test_folder():
    """创建测试文件夹和文件"""
    test_folder = "test_getname_folder"
    if not os.path.exists(test_folder):
        os.makedirs(test_folder)
    
    # 创建一些测试文件
    test_files = [
        "image001.jpg",
        "image002.png", 
        "document.txt",
        "data.csv",
        "photo.gif"
    ]
    
    for filename in test_files:
        filepath = os.path.join(test_folder, filename)
        with open(filepath, 'w') as f:
            f.write(f"Test file: {filename}")
    
    return os.path.abspath(test_folder)

def test_config_save_load():
    """测试配置保存和加载"""
    print("=== 测试配置保存和加载功能 ===")
    
    # 清理旧配置
    if os.path.exists(GETNAME_CONFIG_FILE):
        os.remove(GETNAME_CONFIG_FILE)
    
    # 创建测试文件夹
    test_folder = create_test_folder()
    print(f"创建测试文件夹: {test_folder}")
    
    # 测试保存配置
    test_config = {
        "last_folder_path": test_folder,
        "show_suffix": False,
        "selected_types": [".jpg", ".png"]
    }
    
    save_getname_config(test_config)
    print("✅ 配置保存成功")
    
    # 测试加载配置
    loaded_config = load_getname_config()
    print(f"✅ 配置加载成功: {loaded_config}")
    
    # 验证配置内容
    assert loaded_config["last_folder_path"] == test_folder
    assert loaded_config["show_suffix"] == False
    assert loaded_config["selected_types"] == [".jpg", ".png"]
    print("✅ 配置内容验证通过")
    
    return test_folder

def test_window_memory():
    """测试窗口的路径记忆功能"""
    print("\n=== 测试窗口路径记忆功能 ===")
    
    app = QApplication(sys.argv)
    
    # 第一次打开窗口
    print("第一次打开窗口...")
    window1 = GetNameWindow()
    
    # 检查是否自动加载了路径
    if window1.folder_path:
        print(f"✅ 自动加载了上次的路径: {window1.folder_path}")
        print(f"✅ 文件夹输入框显示: {window1.folder_entry.text()}")
        
        # 检查是否加载了文件
        if window1.filenames:
            print(f"✅ 自动加载了 {len(window1.filenames)} 个文件")
        else:
            print("❌ 没有加载文件")
    else:
        print("❌ 没有自动加载路径")
    
    # 检查显示后缀选项
    print(f"✅ 显示后缀选项: {window1.show_suffix_cb.isChecked()}")
    
    # 检查文件类型选择
    if window1.type_checkboxes:
        selected_types = [cb.text() for cb in window1.type_checkboxes if cb.isChecked()]
        print(f"✅ 选中的文件类型: {selected_types}")
    
    window1.close()
    app.quit()

def cleanup():
    """清理测试文件"""
    import shutil
    
    # 清理测试文件夹
    test_folder = "test_getname_folder"
    if os.path.exists(test_folder):
        shutil.rmtree(test_folder)
        print(f"清理测试文件夹: {test_folder}")
    
    # 清理配置文件
    if os.path.exists(GETNAME_CONFIG_FILE):
        os.remove(GETNAME_CONFIG_FILE)
        print(f"清理配置文件: {GETNAME_CONFIG_FILE}")

def main():
    """主测试函数"""
    try:
        # 测试配置功能
        test_folder = test_config_save_load()
        
        # 测试窗口记忆功能
        test_window_memory()
        
        print("\n🎉 所有测试通过！")
        print("\n功能说明：")
        print("1. 程序会自动记住上次选择的文件夹路径")
        print("2. 记住显示后缀的选择")
        print("3. 记住选中的文件类型")
        print("4. 下次打开时自动恢复这些设置")
        
    except Exception as e:
        print(f"❌ 测试失败: {e}")
        import traceback
        traceback.print_exc()
    finally:
        cleanup()

if __name__ == "__main__":
    main()
