from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QTextEdit, QTabWidget, QWidget
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QIcon
import os
from datetime import datetime

class HistoryWindow(QDialog):
    def __init__(self, history_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle("历史搜索记录")
        self.setMinimumSize(700, 500)
        layout = QVBoxLayout(self)
        icon_path = os.path.join(os.path.dirname(__file__), "history.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            

        # 只展示 dict 类型的历史记录，并按时间倒序排列
        dict_records = [r for r in history_data if isinstance(r, dict)]
        # 按时间倒序排列（假设timestamp格式为"%Y-%m-%d %H:%M:%S"）
        def get_time(record):
            try:
                return datetime.strptime(record.get('timestamp', ''), "%Y-%m-%d %H:%M:%S")
            except Exception:
                return datetime.min
        dict_records.sort(key=get_time, reverse=True)

        # 保存所有历史记录到txt
        if dict_records:
            txt_path = os.path.join(os.path.dirname(__file__), "history.txt")
            with open(txt_path, "w", encoding="utf-8") as f:
                for idx, record in enumerate(dict_records, 1):
                    f.write(f"记录{idx}\n")
                    f.write(f"时间：{record.get('timestamp', '')}\n")
                    f.write("搜索名称列表：\n")
                    for name in record.get("search_names", []):
                        f.write(f"  {name}\n")
                    f.write("找到的文件：\n")
                    for name, path in record.get("found_files", []):
                        f.write(f"  {name}  (路径: {path})\n")
                    f.write("未找到的名称：\n")
                    for name in record.get("not_found_names", []):
                        f.write(f"  {name}\n")
                    f.write("\n" + "-"*40 + "\n\n")

        if not dict_records:
            layout.addWidget(QLabel("暂无历史记录"))
            return

        tab_widget = QTabWidget()
        for idx, record in enumerate(dict_records):
            tab = QWidget()
            tab_layout = QVBoxLayout(tab)
            tab_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
            tab_layout.addWidget(QLabel(f"时间：{record.get('timestamp', '')}"))
            # 搜索名称
            search_names = "\n".join(record.get("search_names", []))
            tab_layout.addWidget(QLabel("搜索名称列表："))
            search_names_edit = QTextEdit(search_names)
            search_names_edit.setReadOnly(True)
            tab_layout.addWidget(search_names_edit)
            # 找到的文件
            found_files = record.get("found_files", [])
            found_text = "\n".join([f"{name}  (路径: {path})" for name, path in found_files])
            tab_layout.addWidget(QLabel("找到的文件："))
            found_edit = QTextEdit(found_text)
            found_edit.setReadOnly(True)
            tab_layout.addWidget(found_edit)
            # 未找到
            not_found = "\n".join(record.get("not_found_names", []))
            tab_layout.addWidget(QLabel("未找到的名称："))
            not_found_edit = QTextEdit(not_found)
            not_found_edit.setReadOnly(True)
            tab_layout.addWidget(not_found_edit)
            tab_widget.addTab(tab, f"记录{idx+1}")
        layout.addWidget(tab_widget)

