from PyQt6.QtWidgets import (QWidget, QGridLayout, QPushButton, QMessageBox, 
                             QVBoxLayout, QHBoxLayout, QLabel, QComboBox, 
                             QSpinBox, QProgressBar, QFrame, QApplication)
from PyQt6.QtCore import QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
#from game2 import GameManager
import random
import sys
import os
class DifficultySelector(QWidget):
    """难度选择界面"""
    game_started = pyqtSignal(dict)
    
    def __init__(self):
        super().__init__()
        self.init_ui()

    
    def init_ui(self):
        self.setWindowTitle("记忆挑战 - 难度选择")
        self.setFixedSize(500, 750)
        icon_path = os.path.join(os.path.dirname(__file__), "游戏.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        
        layout = QVBoxLayout(self)
        
        # 标题
        title = QLabel("🧠 Memory challenge game")
        title.setFont(QFont("Arial", 20, QFont.Weight.Bold))
        title.setStyleSheet("color: #2c3e50; margin: 20px;")
        layout.addWidget(title)

        
        # 难度预设
        preset_frame = QFrame()
        preset_frame.setStyleSheet("QFrame { border: 2px solid #3498db; border-radius: 10px; padding: 10px; }")
        preset_layout = QVBoxLayout(preset_frame)
        
        preset_label = QLabel("🎯 选择难度等级:")
        preset_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        preset_layout.addWidget(preset_label)
        
        self.difficulty_combo = QComboBox()
        self.difficulty_combo.addItems([
            "😊 简单 (3x3, 3个目标, 3秒)",
            "🤔 普通 (4x4, 4个目标, 2秒)", 
            "😰 困难 (5x5, 6个目标, 1.5秒)",
            "🔥 地狱 (6x6, 8个目标, 1秒)",
            "🎨 自定义"
        ])
        self.difficulty_combo.currentTextChanged.connect(self.on_difficulty_changed)
        preset_layout.addWidget(self.difficulty_combo)
        
        layout.addWidget(preset_frame)
        
        # 自定义设置
        custom_frame = QFrame()
        custom_frame.setStyleSheet("QFrame { border: 2px solid #e74c3c; border-radius: 10px; padding: 10px; }")
        custom_layout = QVBoxLayout(custom_frame)
        
        custom_label = QLabel("⚙️ 自定义设置:")
        custom_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        custom_layout.addWidget(custom_label)
        
        # 网格大小
        grid_layout = QHBoxLayout()
        grid_layout.addWidget(QLabel("网格大小:"))
        self.grid_spin = QSpinBox()
        self.grid_spin.setRange(3, 8)
        self.grid_spin.setValue(4)
        grid_layout.addWidget(self.grid_spin)
        custom_layout.addLayout(grid_layout)
        
        # 目标数量
        targets_layout = QHBoxLayout()
        targets_layout.addWidget(QLabel("目标数量:"))
        self.targets_spin = QSpinBox()
        self.targets_spin.setRange(2, 20)
        self.targets_spin.setValue(4)
        targets_layout.addWidget(self.targets_spin)
        custom_layout.addLayout(targets_layout)
        
        # 显示时间
        time_layout = QHBoxLayout()
        time_layout.addWidget(QLabel("显示时间(秒):"))
        self.time_spin = QSpinBox()
        self.time_spin.setRange(1, 10)
        self.time_spin.setValue(2)
        time_layout.addWidget(self.time_spin)
        custom_layout.addLayout(time_layout)
        
        layout.addWidget(custom_frame)
        
        # 游戏模式
        mode_frame = QFrame()
        mode_frame.setStyleSheet("QFrame { border: 2px solid #9b59b6; border-radius: 10px; padding: 10px; }")
        mode_layout = QVBoxLayout(mode_frame)
        
        mode_label = QLabel("🎮 游戏模式:")
        mode_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        mode_layout.addWidget(mode_label)
        
        self.mode_combo = QComboBox()
        self.mode_combo.addItems([
            "🎯 经典模式 - 一次性挑战",
            "⚡ 连续模式 - 逐步增加难度",
            "⏱️ 限时模式 - 时间压力挑战"
        ])
        mode_layout.addWidget(self.mode_combo)
        
        layout.addWidget(mode_frame)
        
        # 开始按钮
        start_btn = QPushButton("🚀 开始游戏")
        start_btn.setFont(QFont("Arial", 14, QFont.Weight.Bold))
        start_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                border: none;
                border-radius: 10px;
                padding: 15px;
                margin: 20px;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
            QPushButton:pressed {
                background-color: #229954;
            }
        """)
        start_btn.clicked.connect(self.start_game)
        layout.addWidget(start_btn)
        
        # 初始设置
        self.custom_widgets = [self.grid_spin, self.targets_spin, self.time_spin]
        for widget in self.custom_widgets:
            widget.setEnabled(False)
    
    def on_difficulty_changed(self, text):
        is_custom = "自定义" in text
        for widget in self.custom_widgets:
            widget.setEnabled(is_custom)
        
        if not is_custom:
            if "简单" in text:
                self.grid_spin.setValue(3)
                self.targets_spin.setValue(3)
                self.time_spin.setValue(3)
            elif "普通" in text:
                self.grid_spin.setValue(4)
                self.targets_spin.setValue(4)
                self.time_spin.setValue(2)
            elif "困难" in text:
                self.grid_spin.setValue(5)
                self.targets_spin.setValue(6)
                self.time_spin.setValue(2)
            elif "地狱" in text:
                self.grid_spin.setValue(6)
                self.targets_spin.setValue(8)
                self.time_spin.setValue(1)
    
    def start_game(self):
        config = {
            'grid_size': self.grid_spin.value(),
            'lights_on': self.targets_spin.value(),
            'show_time': self.time_spin.value(),
            'mode': self.mode_combo.currentIndex(),
            'difficulty_name': self.difficulty_combo.currentText().split()[1]
        }
        
        # 验证设置
        max_targets = config['grid_size'] * config['grid_size']
        if config['lights_on'] > max_targets:
            QMessageBox.warning(self, "设置错误", f"目标数量不能超过网格总数({max_targets})")
            return
            
        self.game_started.emit(config)
        self.hide()


class MemoryGame(QWidget):
    """增强版记忆游戏"""
    
    def __init__(self, config):
        super().__init__()
        icon_path = os.path.join(os.path.dirname(__file__), "游戏.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        self.config = config
        self.grid_size = config['grid_size']
        self.lights_on = config['lights_on']
        self.show_time = config['show_time']
        self.mode = config['mode']
        self.difficulty_name = config['difficulty_name']

        
        # 游戏状态
        self.buttons = []
        self.target_positions = set()
        self.found_positions = set()
        self.score = 0
        self.level = 1
        self.mistakes = 0
        self.max_mistakes = 3
        self.time_left = 30  # 限时模式用
        self.game_active = False
        
        # 计时器
        self.pattern_timer = QTimer()
        self.countdown_timer = QTimer()
        self.countdown_timer.timeout.connect(self.update_countdown)
        
        self.init_ui()
        self.start_level()
    
    def init_ui(self):
        self.setWindowTitle(f"记忆挑战 - {self.difficulty_name}模式")
        
        main_layout = QVBoxLayout(self)
        
        # 信息面板
        info_frame = QFrame()
        info_frame.setStyleSheet("QFrame { background-color: #ecf0f1; border-radius: 10px; padding: 10px; }")
        info_layout = QGridLayout(info_frame)
        
        # 分数
        self.score_label = QLabel(f"💯 分数: {self.score}")
        self.score_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        info_layout.addWidget(self.score_label, 0, 0)
        
        # 等级（连续模式）
        if self.mode == 1:  # 连续模式
            self.level_label = QLabel(f"🎯 等级: {self.level}")
            self.level_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
            info_layout.addWidget(self.level_label, 0, 1)
        
        # 错误次数
        self.mistakes_label = QLabel(f"❌ 错误: {self.mistakes}/{self.max_mistakes}")
        self.mistakes_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        info_layout.addWidget(self.mistakes_label, 0, 2)
        
        # 时间（限时模式）
        if self.mode == 2:  # 限时模式
            self.time_label = QLabel(f"⏰ 时间: {self.time_left}s")
            self.time_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
            info_layout.addWidget(self.time_label, 1, 0)
        
        # 进度条
        self.progress_label = QLabel("🎯 进度:")
        info_layout.addWidget(self.progress_label, 1, 1)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setMaximum(self.lights_on)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 2px solid #3498db;
                border-radius: 5px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #27ae60;
                border-radius: 3px;
            }
        """)
        info_layout.addWidget(self.progress_bar, 1, 2)
        
        main_layout.addWidget(info_frame)
        
        # 游戏网格
        self.game_frame = QFrame()
        self.game_frame.setStyleSheet("QFrame { border: 3px solid #34495e; border-radius: 15px; padding: 10px; }")
        grid_layout = QGridLayout(self.game_frame)
        
        for i in range(self.grid_size):
            row = []
            for j in range(self.grid_size):
                btn = QPushButton()
                btn.setFixedSize(60, 60)
                btn.setStyleSheet("""
                    QPushButton {
                        background-color: #bdc3c7;
                        border: 2px solid #7f8c8d;
                        border-radius: 8px;
                        font-size: 16px;
                        font-weight: bold;
                    }
                    QPushButton:hover {
                        background-color: #d5dbdb;
                        border-color: #5d6d7e;
                    }
                """)
                btn.clicked.connect(self.make_click_handler(i, j))
                grid_layout.addWidget(btn, i, j)
                row.append(btn)
            self.buttons.append(row)
        
        main_layout.addWidget(self.game_frame)
        
        # 控制按钮
        control_layout = QHBoxLayout()
        
        self.hint_btn = QPushButton("💡 提示")
        self.hint_btn.clicked.connect(self.show_hint)
        self.hint_btn.setEnabled(False)
        control_layout.addWidget(self.hint_btn)
        
        restart_btn = QPushButton("🔄 重新开始")
        restart_btn.clicked.connect(self.restart_game)
        control_layout.addWidget(restart_btn)
        
        menu_btn = QPushButton("🏠 返回菜单")
        menu_btn.clicked.connect(self.back_to_menu)
        control_layout.addWidget(menu_btn)
        
        for btn in [self.hint_btn, restart_btn, menu_btn]:
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #3498db;
                    color: white;
                    border: none;
                    border-radius: 8px;
                    padding: 10px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
            """)
        
        main_layout.addLayout(control_layout)
    
    def make_click_handler(self, i, j):
        def handler():
            if not self.game_active:
                return
                
            if (i, j) in self.target_positions and (i, j) not in self.found_positions:
                # 正确点击
                self.buttons[i][j].setStyleSheet("""
                    QPushButton {
                        background-color: #27ae60;
                        border: 2px solid #229954;
                        border-radius: 8px;
                        color: white;
                        font-size: 16px;
                        font-weight: bold;
                    }
                """)
                self.buttons[i][j].setText("✓")
                self.found_positions.add((i, j))
                self.score += 10 * self.level
                self.update_ui()
                
                if len(self.found_positions) == len(self.target_positions):
                    self.level_complete()
            else:
                # 错误点击
                self.buttons[i][j].setStyleSheet("""
                    QPushButton {
                        background-color: #e74c3c;
                        border: 2px solid #c0392b;
                        border-radius: 8px;
                        color: white;
                        font-size: 16px;
                        font-weight: bold;
                    }
                """)
                self.buttons[i][j].setText("✗")
                self.mistakes += 1
                self.score = max(0, self.score - 5)
                self.update_ui()
                
                if self.mistakes >= self.max_mistakes:
                    self.game_over()
                else:
                    QTimer.singleShot(1000, lambda: self.reset_button(i, j))
        
        return handler
    
    def reset_button(self, i, j):
        self.buttons[i][j].setStyleSheet("""
            QPushButton {
                background-color: #bdc3c7;
                border: 2px solid #7f8c8d;
                border-radius: 8px;
                font-size: 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #d5dbdb;
                border-color: #5d6d7e;
            }
        """)
        self.buttons[i][j].setText("")
    
    def start_level(self):
        self.game_active = False
        self.found_positions.clear()
        
        # 连续模式：逐步增加难度
        if self.mode == 1:
            current_targets = min(self.lights_on + (self.level - 1), self.grid_size * self.grid_size)
        else:
            current_targets = self.lights_on
        
        # 重置按钮
        for row in self.buttons:
            for btn in row:
                btn.setStyleSheet("""
                    QPushButton {
                        background-color: #bdc3c7;
                        border: 2px solid #7f8c8d;
                        border-radius: 8px;
                        font-size: 16px;
                        font-weight: bold;
                    }
                    QPushButton:hover {
                        background-color: #d5dbdb;
                        border-color: #5d6d7e;
                    }
                """)
                btn.setText("")
        
        # 生成目标位置
        all_positions = [(i, j) for i in range(self.grid_size) for j in range(self.grid_size)]
        self.target_positions = set(random.sample(all_positions, current_targets))
        
        # 显示模式
        self.show_pattern()
        
        # 限时模式启动倒计时
        if self.mode == 2:
            self.time_left = 30 + self.level * 5  # 随等级增加时间
            self.countdown_timer.start(1000)
    
    def show_pattern(self):
        # 显示目标位置
        for i, j in self.target_positions:
            self.buttons[i][j].setStyleSheet("""
                QPushButton {
                    background-color: #f1c40f;
                    border: 2px solid #f39c12;
                    border-radius: 8px;
                    color: #2c3e50;
                    font-size: 16px;
                    font-weight: bold;
                }
            """)
            self.buttons[i][j].setText("★")
        
        # 设置隐藏计时器
        show_time_ms = int(self.show_time * 1000)
        self.pattern_timer.singleShot(show_time_ms, self.hide_pattern)
    
    def hide_pattern(self):
        # 隐藏模式，开始游戏
        for row in self.buttons:
            for btn in row:
                btn.setStyleSheet("""
                    QPushButton {
                        background-color: #bdc3c7;
                        border: 2px solid #7f8c8d;
                        border-radius: 8px;
                        font-size: 16px;
                        font-weight: bold;
                    }
                    QPushButton:hover {
                        background-color: #d5dbdb;
                        border-color: #5d6d7e;
                    }
                """)
                btn.setText("")
        
        self.game_active = True
        self.hint_btn.setEnabled(True)
        self.update_ui()
    
    def show_hint(self):
        if not self.target_positions or len(self.found_positions) >= len(self.target_positions):
            return
        
        # 随机显示一个未找到的目标
        remaining = self.target_positions - self.found_positions
        if remaining:
            i, j = random.choice(list(remaining))
            self.buttons[i][j].setStyleSheet("""
                QPushButton {
                    background-color: #9b59b6;
                    border: 2px solid #8e44ad;
                    border-radius: 8px;
                    color: white;
                    font-size: 16px;
                    font-weight: bold;
                }
            """)
            self.buttons[i][j].setText("?")
            
            # 扣分并1秒后恢复
            self.score = max(0, self.score - 15)
            self.update_ui()
            QTimer.singleShot(1000, lambda: self.reset_button(i, j))
    
    def level_complete(self):
        self.game_active = False
        self.countdown_timer.stop()
        
        bonus = len(self.target_positions) * 5
        self.score += bonus
        
        if self.mode == 1:  # 连续模式
            self.level += 1
            msg = f"🎉 第 {self.level-1} 关完成！\n获得 {bonus} 分奖励\n准备下一关..."
            QMessageBox.information(self, "关卡完成", msg)
            self.start_level()
        else:
            msg = f"🏆 恭喜完成！\n最终得分: {self.score}\n奖励: +{bonus} 分"
            QMessageBox.information(self, "游戏完成", msg)
            self.back_to_menu()
    
    def game_over(self):
        self.game_active = False
        self.countdown_timer.stop()
        
        msg = f"💀 游戏结束！\n最终得分: {self.score}\n完成等级: {self.level}"
        QMessageBox.information(self, "游戏结束", msg)
        self.back_to_menu()
    
    def update_countdown(self):
        self.time_left -= 1
        if hasattr(self, 'time_label'):
            self.time_label.setText(f"⏰ 时间: {self.time_left}s")
        
        if self.time_left <= 0:
            self.game_over()
    
    def update_ui(self):
        self.score_label.setText(f"💯 分数: {self.score}")
        if hasattr(self, 'level_label'):
            self.level_label.setText(f"🎯 等级: {self.level}")
        self.mistakes_label.setText(f"❌ 错误: {self.mistakes}/{self.max_mistakes}")
        self.progress_bar.setValue(len(self.found_positions))
    
    def restart_game(self):
        self.score = 0
        self.level = 1
        self.mistakes = 0
        self.countdown_timer.stop()
        self.start_level()
    
    def back_to_menu(self):
        self.countdown_timer.stop()
        self.hide()
        # 确保主页始终显示
        parent = self.parent()
        # 兼容GameManager作为父窗口或通过destroyed信号
        if parent and hasattr(parent, 'difficulty_selector'):
            parent.difficulty_selector.show()
        else:
            # 通过遍历所有顶层窗口找到主页
            for widget in QApplication.topLevelWidgets():
                if hasattr(widget, 'difficulty_selector'):
                    widget.difficulty_selector.show()


class GameManager(QWidget):
    """游戏管理器"""
    
    def __init__(self):
        super().__init__()
        self.difficulty_selector = DifficultySelector()
        self.current_game = None
        self.difficulty_selector.game_started.connect(self.start_game)
    
    def start_game(self, config):
        if self.current_game:
            self.current_game.hide()
        self.current_game = MemoryGame(config)
        self.current_game.show()
        self.current_game.destroyed.connect(self.show_menu)
    
    def show_menu(self):
        self.current_game = None
        self.difficulty_selector.show()


def main():
    app = QApplication(sys.argv)
    
    # 设置应用样式
    app.setStyle('Fusion')
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(240, 240, 240))
    app.setPalette(palette)
    
    game_manager = GameManager()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()