from PyQt6.QtWidgets import (QDialog, QGridLayout, QLineEdit, QPushButton, QMessageBox, 
                            QHBoxLayout, QVBoxLayout, QLabel, QComboBox, QProgressBar, 
                            QTextEdit, QGroupBox, QCheckBox, QSlider, QSpinBox, QApplication)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QFont, QPalette, QColor
import random
import json
import time
from datetime import datetime

# --- 新增：数独生成器 ---
class SudokuGenerator:
    """一个能够生成唯一解数独题目的生成器"""
    def __init__(self):
        self.grid = [[0 for _ in range(9)] for _ in range(9)]

    def generate(self, difficulty):
        # 1. 生成一个完整的随机数独解
        self.grid = [[0 for _ in range(9)] for _ in range(9)]
        self._solve_randomized(self.grid)

        # 2. 根据难度挖空
        # 难度越高，挖的孔越多，尝试次数也越多
        if difficulty == "简单":
            # 大约移除40-45个
            attempts = 50 
            limit = 45
        elif difficulty == "中等":
            # 大约移除48-53个
            attempts = 60
            limit = 53
        else: # 困难
            # 大约移除54-59个
            attempts = 70
            limit = 59
        
        puzzle = [row[:] for row in self.grid]
        
        removed_cells = 0
        while attempts > 0 and removed_cells < limit:
            row = random.randint(0, 8)
            col = random.randint(0, 8)

            if puzzle[row][col] != 0:
                backup = puzzle[row][col]
                puzzle[row][col] = 0
                
                # 创建一个副本进行求解
                puzzle_copy = [r[:] for r in puzzle]
                
                if self._count_solutions(puzzle_copy) != 1:
                    # 如果解不唯一，则恢复该数字
                    puzzle[row][col] = backup
                else:
                    removed_cells += 1

            attempts -= 1
        return puzzle

    def _get_empty(self, board):
        for i in range(9):
            for j in range(9):
                if board[i][j] == 0:
                    return (i, j)
        return None

    def _is_safe(self, board, row, col, num):
        # 检查行、列和3x3方块
        for x in range(9):
            if board[row][x] == num or board[x][col] == num:
                return False
        
        start_row, start_col = 3 * (row // 3), 3 * (col // 3)
        for i in range(3):
            for j in range(3):
                if board[i + start_row][j + start_col] == num:
                    return False
        return True

    def _solve_randomized(self, board):
        # 使用随机数字顺序的回溯算法填充整个网格
        find = self._get_empty(board)
        if not find:
            return True
        row, col = find

        nums = list(range(1, 10))
        random.shuffle(nums)

        for num in nums:
            if self._is_safe(board, row, col, num):
                board[row][col] = num
                if self._solve_randomized(board):
                    return True
                board[row][col] = 0
        return False

    def _count_solutions(self, board):
        # 计算数独解的数量
        find = self._get_empty(board)
        if not find:
            return 1
        
        row, col = find
        count = 0
        for num in range(1, 10):
            if self._is_safe(board, row, col, num):
                board[row][col] = num
                count += self._count_solutions(board)
                # 优化：一旦找到超过1个解，就没必要继续了
                if count > 1:
                    board[row][col] = 0 # 回溯
                    return count
                board[row][col] = 0 # 回溯
        return count


# 预置题库（增加更多题目）
SUDOKU_QUESTIONS = {
    "简单": [
        [
            [5, 3, 0, 0, 7, 0, 0, 0, 0],
            [6, 0, 0, 1, 9, 5, 0, 0, 0],
            [0, 9, 8, 0, 0, 0, 0, 6, 0],
            [8, 0, 0, 0, 6, 0, 0, 0, 3],
            [4, 0, 0, 8, 0, 3, 0, 0, 1],
            [7, 0, 0, 0, 2, 0, 0, 0, 6],
            [0, 6, 0, 0, 0, 0, 2, 8, 0],
            [0, 0, 0, 4, 1, 9, 0, 0, 5],
            [0, 0, 0, 0, 8, 0, 0, 7, 9]
        ],
        [
            [0, 2, 0, 6, 0, 8, 0, 0, 0],
            [5, 8, 0, 0, 0, 9, 7, 0, 0],
            [0, 0, 0, 0, 4, 0, 0, 0, 0],
            [3, 7, 0, 0, 0, 0, 5, 0, 0],
            [6, 0, 0, 0, 0, 0, 0, 0, 4],
            [0, 0, 8, 0, 0, 0, 0, 1, 3],
            [0, 0, 0, 0, 2, 0, 0, 0, 0],
            [0, 0, 9, 8, 0, 0, 0, 3, 6],
            [0, 0, 0, 3, 0, 6, 0, 9, 0]
        ],
        [
            [1, 0, 0, 4, 8, 9, 0, 0, 6],
            [7, 3, 0, 0, 0, 0, 0, 4, 0],
            [0, 0, 0, 0, 0, 1, 2, 9, 5],
            [0, 0, 7, 1, 2, 0, 6, 0, 0],
            [5, 0, 0, 7, 0, 3, 0, 0, 8],
            [0, 0, 6, 0, 9, 5, 7, 0, 0],
            [9, 1, 4, 6, 0, 0, 0, 0, 0],
            [0, 2, 0, 0, 0, 0, 0, 3, 7],
            [8, 0, 0, 5, 1, 2, 0, 0, 4]
        ],
        [
            [2, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 6, 0, 0, 0, 0, 3],
            [0, 7, 4, 0, 8, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 3, 0, 0, 2],
            [0, 8, 0, 0, 4, 0, 0, 1, 0],
            [6, 0, 0, 5, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 0, 7, 8, 0],
            [5, 0, 0, 0, 0, 9, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 4]
        ],
        [
            [0, 0, 0, 8, 0, 1, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 4, 3],
            [5, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 7, 0, 8, 0, 0],
            [0, 0, 0, 0, 0, 0, 1, 0, 0],
            [0, 2, 0, 0, 3, 0, 0, 0, 0],
            [6, 0, 0, 0, 0, 0, 0, 7, 5],
            [0, 0, 3, 4, 0, 0, 0, 0, 0],
            [0, 0, 0, 2, 0, 0, 6, 0, 0]
        ]
    ],
    "中等": [
        [
            [0, 0, 0, 6, 0, 0, 4, 0, 0],
            [7, 0, 0, 0, 0, 3, 6, 0, 0],
            [0, 0, 0, 0, 9, 1, 0, 8, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 5, 0, 1, 8, 0, 0, 0, 3],
            [0, 0, 0, 3, 0, 6, 0, 4, 5],
            [0, 4, 0, 2, 0, 0, 0, 6, 0],
            [9, 0, 3, 0, 0, 0, 0, 0, 0],
            [0, 2, 0, 0, 0, 0, 1, 0, 0]
        ],
        [
            [0, 2, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 6, 0, 0, 0, 0, 3],
            [0, 7, 4, 0, 8, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 3, 0, 0, 2],
            [0, 8, 0, 0, 4, 0, 0, 1, 0],
            [6, 0, 0, 5, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 1, 0, 7, 8, 0],
            [5, 0, 0, 0, 0, 9, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 4, 0]
        ],
        [
            [0, 0, 0, 0, 0, 0, 0, 1, 2],
            [0, 0, 0, 0, 0, 7, 0, 0, 0],
            [0, 0, 1, 0, 9, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 5, 3, 8, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 8, 0, 9, 0, 0],
            [0, 0, 0, 2, 0, 0, 0, 0, 0],
            [8, 2, 0, 0, 0, 0, 0, 0, 0]
        ],
        [
            [0, 0, 1, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 2, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 3, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 4],
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 5, 0, 0, 0],
            [0, 0, 0, 0, 6, 0, 0, 0, 0],
            [0, 7, 0, 0, 0, 0, 0, 0, 0],
            [8, 0, 0, 0, 0, 0, 0, 0, 0]
        ]
    ],
    "困难": [
        [
            [8, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 3, 6, 0, 0, 0, 0, 0],
            [0, 7, 0, 0, 9, 0, 2, 0, 0],
            [0, 5, 0, 0, 0, 7, 0, 0, 0],
            [0, 0, 0, 0, 4, 5, 7, 0, 0],
            [0, 0, 0, 1, 0, 0, 0, 3, 0],
            [0, 0, 1, 0, 0, 0, 0, 6, 8],
            [0, 0, 8, 5, 0, 0, 0, 1, 0],
            [0, 9, 0, 0, 0, 0, 4, 0, 0]
        ],
        [
            [1, 0, 0, 0, 0, 7, 0, 9, 0],
            [0, 3, 0, 0, 2, 0, 0, 0, 8],
            [0, 0, 9, 6, 0, 0, 5, 0, 0],
            [0, 0, 5, 3, 0, 0, 9, 0, 0],
            [0, 1, 0, 0, 8, 0, 0, 0, 2],
            [6, 0, 0, 0, 0, 4, 0, 0, 0],
            [3, 0, 0, 0, 0, 0, 0, 1, 0],
            [0, 4, 0, 0, 0, 0, 0, 0, 7],
            [0, 0, 7, 0, 0, 0, 3, 0, 0]
        ],
        [
            [0, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 3, 0, 8, 5],
            [0, 0, 1, 0, 2, 0, 0, 0, 0],
            [0, 0, 0, 5, 0, 7, 0, 0, 0],
            [0, 0, 4, 0, 0, 0, 1, 0, 0],
            [0, 9, 0, 0, 0, 0, 0, 0, 0],
            [5, 0, 0, 0, 0, 0, 0, 7, 3],
            [0, 0, 2, 0, 1, 0, 0, 0, 0],
            [0, 0, 0, 0, 4, 0, 0, 0, 9]
        ],
        [
            [0, 0, 0, 7, 0, 0, 0, 0, 0],
            [1, 0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 4, 3, 0, 2, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0, 6],
            [0, 0, 0, 5, 0, 9, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 4, 1, 8],
            [0, 0, 0, 0, 8, 1, 0, 0, 0],
            [0, 0, 2, 0, 0, 0, 0, 5, 0],
            [0, 4, 0, 0, 0, 0, 3, 0, 0]
        ]
    ]
}

class SudokuCell(QLineEdit):
    """自定义数独单元格"""
    def __init__(self, row, col, parent=None):
        super().__init__(parent)
        self.row = row
        self.col = col
        self.notes = set()  # 存储笔记
        self.is_original = False  # 是否是原始题目数字
        self.setup_ui()
    
    def setup_ui(self):
        self.setFixedSize(40, 40)
        self.setMaxLength(1)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFont(QFont("Arial", 16, QFont.Weight.Bold))
        self.update_style()
    
    def update_style(self):
        if self.is_original:
            self.setStyleSheet("""
                QLineEdit { 
                    font-size: 16px; 
                    background-color: #f0f0f0; 
                    color: #000080;
                    border: 1px solid #666;
                    font-weight: bold;
                }
            """)
        else:
            self.setStyleSheet("""
                QLineEdit { 
                    font-size: 16px; 
                    background-color: #ffffff; 
                    color: #000000;
                    border: 1px solid #666;
                }
            """)
    
    def set_note_mode(self, enabled):
        if enabled and not self.is_original:
            self.setStyleSheet("""
                QLineEdit { 
                    font-size: 10px; 
                    background-color: #ffffcc; 
                    color: #666666;
                    border: 1px solid #666;
                }
            """)
        else:
            self.update_style()

class SudokuWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("增强版数独游戏")
        self.setFixedSize(800, 650)
        
        # 游戏状态
        self.start_time = None
        self.current_time = 0
        self.mistakes = 0
        self.hints_used = 0
        self.score = 0
        self.is_paused = False
        self.note_mode = False
        self.current_question = None
        self.solved_count = {"简单": 0, "中等": 0, "困难": 0}
        
        # 新增：数独生成器实例
        self.generator = SudokuGenerator()
        
        # 创建UI组件
        self.grid = [[SudokuCell(i, j, self) for j in range(9)] for i in range(9)]
        self.setup_ui()
        self.setup_timer()
        
        # 加载第一题
        self.load_random_question()
    
    def setup_ui(self):
        main_layout = QHBoxLayout()
        
        # 左侧：游戏面板
        game_layout = QVBoxLayout()
        
        # 顶部控制面板
        top_panel = self.create_top_panel()
        game_layout.addWidget(top_panel)
        
        # 数独网格
        grid_widget = self.create_grid_widget()
        game_layout.addWidget(grid_widget)
        
        # 底部控制按钮
        bottom_panel = self.create_bottom_panel()
        game_layout.addWidget(bottom_panel)
        
        main_layout.addLayout(game_layout)
        
        # 右侧：信息面板
        info_panel = self.create_info_panel()
        main_layout.addWidget(info_panel)
        
        self.setLayout(main_layout)
    
    def create_top_panel(self):
        panel = QGroupBox("游戏设置")
        layout = QHBoxLayout()
        
        # 难度选择
        layout.addWidget(QLabel("难度："))
        self.difficulty_box = QComboBox()
        self.difficulty_box.addItems(["简单", "中等", "困难"])
        self.difficulty_box.currentTextChanged.connect(self.on_difficulty_changed)
        layout.addWidget(self.difficulty_box)
        
        # 新增：随机模式选择框
        self.random_mode_checkbox = QCheckBox("随机生成")
        self.random_mode_checkbox.setToolTip("勾选后，点击“下一关”将生成全新的随机题目")
        layout.addWidget(self.random_mode_checkbox)
        
        # 下一关按钮
        next_btn = QPushButton("下一关")
        next_btn.clicked.connect(self.load_random_question)
        layout.addWidget(next_btn)
        
        # 暂停/继续按钮
        self.pause_btn = QPushButton("暂停")
        self.pause_btn.clicked.connect(self.toggle_pause)
        layout.addWidget(self.pause_btn)
        
        # 重新开始按钮
        restart_btn = QPushButton("重新开始")
        restart_btn.clicked.connect(self.restart_game)
        layout.addWidget(restart_btn)
        
        panel.setLayout(layout)
        return panel
    
    def create_grid_widget(self):
        widget = QGroupBox("数独网格")
        layout = QGridLayout()
        layout.setSpacing(1)
        
        # 添加网格背景区分3x3方块
        for i in range(9):
            for j in range(9):
                cell = self.grid[i][j]
                # 设置3x3方块的背景色
                if (i // 3 + j // 3) % 2 == 0:
                    cell.setProperty("block", "even")
                else:
                    cell.setProperty("block", "odd")
                
                cell.textChanged.connect(self.on_cell_changed)
                layout.addWidget(cell, i, j)
                
                # 添加粗线分隔3x3方块
                if i % 3 == 2 and i != 8:
                    layout.setRowMinimumHeight(i + 1, 3)
                if j % 3 == 2 and j != 8:
                    layout.setColumnMinimumWidth(j + 1, 3)
        
        widget.setLayout(layout)
        return widget
    
    def create_bottom_panel(self):
        panel = QGroupBox("游戏控制")
        layout = QVBoxLayout()
        
        # 第一行按钮
        row1 = QHBoxLayout()
        
        check_btn = QPushButton("检查答案")
        check_btn.clicked.connect(self.check_sudoku)
        row1.addWidget(check_btn)
        
        hint_btn = QPushButton("提示")
        hint_btn.clicked.connect(self.give_hint)
        row1.addWidget(hint_btn)
        
        solve_btn = QPushButton("自动求解")
        solve_btn.clicked.connect(self.auto_solve)
        row1.addWidget(solve_btn)
        
        layout.addLayout(row1)
        
        # 第二行按钮
        row2 = QHBoxLayout()
        
        clear_btn = QPushButton("清空输入")
        clear_btn.clicked.connect(self.clear_input)
        row2.addWidget(clear_btn)
        
        self.note_btn = QPushButton("笔记模式")
        self.note_btn.setCheckable(True)
        self.note_btn.clicked.connect(self.toggle_note_mode)
        row2.addWidget(self.note_btn)
        
        validate_btn = QPushButton("实时验证")
        validate_btn.setCheckable(True)
        validate_btn.clicked.connect(self.toggle_realtime_validation)
        row2.addWidget(validate_btn)
        
        layout.addLayout(row2)
        
        panel.setLayout(layout)
        return panel
    
    def create_info_panel(self):
        panel = QGroupBox("游戏信息")
        panel.setFixedWidth(200)
        layout = QVBoxLayout()
        
        # 计时器显示
        self.time_label = QLabel("时间: 00:00")
        self.time_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        layout.addWidget(self.time_label)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 81)
        layout.addWidget(self.progress_bar)
        
        # 统计信息
        stats_group = QGroupBox("统计")
        stats_layout = QVBoxLayout()
        
        self.mistakes_label = QLabel("错误: 0")
        stats_layout.addWidget(self.mistakes_label)
        
        self.hints_label = QLabel("提示: 0")
        stats_layout.addWidget(self.hints_label)
        
        self.score_label = QLabel("得分: 1000")
        stats_layout.addWidget(self.score_label)
        
        stats_group.setLayout(stats_layout)
        layout.addWidget(stats_group)
        
        # 完成统计
        completed_group = QGroupBox("完成统计")
        completed_layout = QVBoxLayout()
        
        self.easy_label = QLabel("简单: 0")
        completed_layout.addWidget(self.easy_label)
        
        self.medium_label = QLabel("中等: 0")
        completed_layout.addWidget(self.medium_label)
        
        self.hard_label = QLabel("困难: 0")
        completed_layout.addWidget(self.hard_label)
        
        completed_group.setLayout(completed_layout)
        layout.addWidget(completed_group)
        
        # 游戏日志
        log_group = QGroupBox("游戏日志")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(100)
        self.log_text.setReadOnly(True)
        log_layout.addWidget(self.log_text)
        
        log_group.setLayout(log_layout)
        layout.addWidget(log_group)
        
        panel.setLayout(layout)
        return panel
    
    def setup_timer(self):
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.timer.start(1000)  # 每秒更新
    
    def update_timer(self):
        if not self.is_paused and self.start_time:
            self.current_time = int(time.time() - self.start_time)
            minutes = self.current_time // 60
            seconds = self.current_time % 60
            self.time_label.setText(f"时间: {minutes:02d}:{seconds:02d}")
    
    def log_message(self, message):
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")
        # 自动滚动到底部
        self.log_text.verticalScrollBar().setValue(
            self.log_text.verticalScrollBar().maximum()
        )
    
    def on_difficulty_changed(self):
        self.load_random_question()
    
    def load_random_question(self):
        if self.random_mode_checkbox.isChecked():
            difficulty = self.difficulty_box.currentText()
            self.log_message(f"生成随机题目({difficulty})...")
            QApplication.processEvents() # 刷新UI以显示日志
            self.current_question = self.generator.generate(difficulty)
            self.log_message("随机题目已生成！")
        else:
            difficulty = self.difficulty_box.currentText()
            self.current_question = random.choice(SUDOKU_QUESTIONS[difficulty])
        
        # 重置游戏状态
        self.start_time = time.time()
        self.current_time = 0
        self.mistakes = 0
        self.hints_used = 0
        self.score = 1000  # 基础分数
        
        # 加载题目到网格
        filled_cells = 0
        for i in range(9):
            for j in range(9):
                cell = self.grid[i][j]
                val = self.current_question[i][j]
                if val != 0:
                    cell.setText(str(val))
                    cell.setReadOnly(True)
                    cell.is_original = True
                    filled_cells += 1
                else:
                    cell.clear()
                    cell.setReadOnly(False)
                    cell.is_original = False
                    cell.notes.clear()
                cell.update_style()
        
        # 更新进度条
        self.progress_bar.setValue(filled_cells)
        
        # 更新显示
        self.update_stats_display()
        self.log_message(f"开始新游戏 - 难度: {difficulty}")
    
    def on_cell_changed(self):
        if self.is_paused:
            return
            
        # 更新进度条
        filled_cells = sum(1 for i in range(9) for j in range(9) if self.grid[i][j].text())
        self.progress_bar.setValue(filled_cells)
        
        # 检查是否完成
        if filled_cells == 81:
            if self.is_valid_sudoku(self.get_current_board()):
                self.on_puzzle_completed()
    
    def toggle_pause(self):
        self.is_paused = not self.is_paused
        self.pause_btn.setText("继续" if self.is_paused else "暂停")
        
        # 暂停时隐藏网格内容
        for i in range(9):
            for j in range(9):
                self.grid[i][j].setEnabled(not self.is_paused)
        
        self.log_message("游戏暂停" if self.is_paused else "游戏继续")
    
    def restart_game(self):
        self.load_random_question()
    
    def toggle_note_mode(self):
        self.note_mode = self.note_btn.isChecked()
        # 更新所有单元格的显示样式
        for i in range(9):
            for j in range(9):
                self.grid[i][j].set_note_mode(self.note_mode)
        
        self.log_message("进入笔记模式" if self.note_mode else "退出笔记模式")
    
    def toggle_realtime_validation(self):
        # 这里可以添加实时验证逻辑
        self.log_message("实时验证已开启" if self.sender().isChecked() else "实时验证已关闭")
    
    def give_hint(self):
        if self.hints_used >= 3:
            QMessageBox.warning(self, "提示用完", "每局游戏最多只能使用3次提示！")
            return
        
        # 找到一个空白单元格并填入正确答案
        empty_cells = [(i, j) for i in range(9) for j in range(9) 
                      if not self.grid[i][j].text() and not self.grid[i][j].is_original]
        
        if not empty_cells:
            QMessageBox.information(self, "提示", "没有可以提示的位置了！")
            return
        
        # 随机选择一个空白位置
        row, col = random.choice(empty_cells)
        
        # 求解当前状态，获取正确答案
        solved_board = self.solve_sudoku(self.get_current_board())
        if solved_board:
            correct_value = solved_board[row][col]
            self.grid[row][col].setText(str(correct_value))
            self.hints_used += 1
            self.score -= 50  # 使用提示扣分
            
            self.update_stats_display()
            self.log_message(f"使用提示: 第{row+1}行第{col+1}列 = {correct_value}")
    
    def auto_solve(self):
        board = self.get_current_board()
        solved_board = self.solve_sudoku(board)
        
        if solved_board:
            for i in range(9):
                for j in range(9):
                    if not self.grid[i][j].is_original:
                        self.grid[i][j].setText(str(solved_board[i][j]))
            
            self.log_message("自动求解完成")
            QMessageBox.information(self, "求解完成", "数独已自动求解完成！")
        else:
            QMessageBox.warning(self, "无法求解", "当前数独无解或存在错误！")
    
    def clear_input(self):
        for i in range(9):
            for j in range(9):
                if not self.grid[i][j].is_original:
                    self.grid[i][j].clear()
        
        self.log_message("清空所有输入")
    
    def check_sudoku(self):
        try:
            board = self.get_current_board()
            
            # 检查是否有空白
            empty_count = sum(1 for i in range(9) for j in range(9) if board[i][j] == 0)
            if empty_count > 0:
                QMessageBox.information(self, "检查结果", f"还有 {empty_count} 个空白位置")
                return
            
            if self.is_valid_sudoku(board):
                self.on_puzzle_completed()
            else:
                self.mistakes += 1
                self.score -= 20
                self.update_stats_display()
                QMessageBox.warning(self, "有冲突", "当前数独有冲突，请检查！")
                self.log_message("检查结果: 存在冲突")
                
        except Exception as e:
            QMessageBox.critical(self, "错误", str(e))
    
    def on_puzzle_completed(self):
        difficulty = self.difficulty_box.currentText()
        self.solved_count[difficulty] += 1
        
        # 计算最终得分
        time_bonus = max(0, 300 - self.current_time)  # 时间奖励
        difficulty_bonus = {"简单": 100, "中等": 200, "困难": 300}[difficulty]
        final_score = self.score + time_bonus + difficulty_bonus
        
        self.update_completed_stats()
        
        QMessageBox.information(self, "恭喜！", 
            f"数独完成！\n"
            f"用时: {self.current_time//60:02d}:{self.current_time%60:02d}\n"
            f"错误次数: {self.mistakes}\n"
            f"使用提示: {self.hints_used}\n"
            f"最终得分: {final_score}")
        
        self.log_message(f"完成{difficulty}难度数独，得分: {final_score}")
    
    def get_current_board(self):
        board = []
        for i in range(9):
            row = []
            for j in range(9):
                val = self.grid[i][j].text()
                if val == "":
                    row.append(0)
                elif val.isdigit() and 1 <= int(val) <= 9:
                    row.append(int(val))
                else:
                    row.append(0)  # 无效输入视为空白
            board.append(row)
        return board
    
    def update_stats_display(self):
        self.mistakes_label.setText(f"错误: {self.mistakes}")
        self.hints_label.setText(f"提示: {self.hints_used}")
        self.score_label.setText(f"得分: {self.score}")
    
    def update_completed_stats(self):
        self.easy_label.setText(f"简单: {self.solved_count['简单']}")
        self.medium_label.setText(f"中等: {self.solved_count['中等']}")
        self.hard_label.setText(f"困难: {self.solved_count['困难']}")
    
    def is_valid_sudoku(self, board):
        # 检查行
        for i in range(9):
            row = [x for x in board[i] if x != 0]
            if len(row) != len(set(row)):
                return False
        
        # 检查列
        for i in range(9):
            col = [board[x][i] for x in range(9) if board[x][i] != 0]
            if len(col) != len(set(col)):
                return False
        
        # 检查3x3方块
        for block_i in range(3):
            for block_j in range(3):
                block = []
                for i in range(block_i*3, block_i*3+3):
                    for j in range(block_j*3, block_j*3+3):
                        if board[i][j] != 0:
                            block.append(board[i][j])
                if len(block) != len(set(block)):
                    return False
        return True
    
    def solve_sudoku(self, board):
        """使用回溯算法求解数独"""
        def is_safe(board, row, col, num):
            # 检查行
            for x in range(9):
                if board[row][x] == num:
                    return False
            
            # 检查列
            for x in range(9):
                if board[x][col] == num:
                    return False
            
            # 检查3x3方块
            start_row = row - row % 3
            start_col = col - col % 3
            for i in range(3):
                for j in range(3):
                    if board[i + start_row][j + start_col] == num:
                        return False
            return True
        
        def solve(board):
            for i in range(9):
                for j in range(9):
                    if board[i][j] == 0:
                        for num in range(1, 10):
                            if is_safe(board, i, j, num):
                                board[i][j] = num
                                if solve(board):
                                    return True
                                board[i][j] = 0
                        return False
            return True
        
        # 创建副本避免修改原始数据
        board_copy = [row[:] for row in board]
        if solve(board_copy):
            return board_copy
        return None

# 主程序入口
if __name__ == "__main__":
    import sys
    
    app = QApplication(sys.argv)
    window = SudokuWindow()
    window.show()
    sys.exit(app.exec())