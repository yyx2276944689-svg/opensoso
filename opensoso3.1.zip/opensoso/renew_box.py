import sys
import os
import json
import zipfile
import shutil
import re
from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                            QPushButton, QListWidget, QListWidgetItem, 
                            QProgressBar, QTextEdit, QMessageBox, QFrame,
                            QFileDialog)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QFont, QIcon
import requests
from datetime import datetime

# 配置文件路径
CONFIG_FILE = "renew_box_config.json"

def load_config():
    """加载配置文件"""
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def save_config(config):
    """保存配置文件"""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

class DownloadThread(QThread):
    """下载线程"""
    progress = pyqtSignal(int)  # 进度信号
    finished = pyqtSignal(bool, str)  # 完成信号 (成功, 消息)
    
    def __init__(self, url, save_path):
        super().__init__()
        self.url = url
        self.save_path = save_path
        self.is_cancelled = False

    
    def run(self):
        try:
            response = requests.get(self.url, stream=True)
            response.raise_for_status()
            
            total_size = int(response.headers.get('content-length', 0))
            downloaded_size = 0
            
            with open(self.save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if self.is_cancelled:
                        return
                    
                    if chunk:
                        f.write(chunk)
                        downloaded_size += len(chunk)
                        
                        if total_size > 0:
                            progress = int((downloaded_size / total_size) * 100)
                            self.progress.emit(progress)
            
            self.finished.emit(True, "下载完成")
            
        except Exception as e:
            self.finished.emit(False, f"下载失败: {str(e)}")
    
    def cancel(self):
        self.is_cancelled = True

class UpdateBox(QDialog):
    """更新界面"""
    
    def __init__(self):
        super().__init__()
        self.current_version = "opensoso2.6"
        self.server_url = "http://47.97.29.42:5000"
        self.download_thread = None
        
        # 加载配置，记住下载路径
        config = load_config()
        saved_path = config.get('download_path', '')
        if saved_path and os.path.exists(saved_path):
            self.download_path = saved_path
        else:
            # 默认下载路径为用户下载文件夹
            self.download_path = os.path.join(os.path.expanduser("~"), "Downloads")
        
        icon_path = os.path.join(os.path.dirname(__file__), "genxin.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        self.init_ui()
        self.load_versions()
    
    def init_ui(self):
        self.setWindowTitle("Opensoso 更新管理器")
        self.setFixedSize(600, 550)  # 稍微增加高度以容纳新组件
        self.setWindowFlags(Qt.WindowType.Dialog | Qt.WindowType.WindowCloseButtonHint)
        
        # 主布局
        layout = QVBoxLayout()
        layout.setSpacing(10)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # 标题
        title_label = QLabel("Opensoso 更新管理器")
        title_font = QFont()
        title_font.setPointSize(16)
        title_font.setBold(True)
        title_label.setFont(title_font)
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)
        
        # 当前版本信息
        version_frame = QFrame()
        version_frame.setFrameStyle(QFrame.Shape.Box)
        version_layout = QVBoxLayout()
        
        current_version_label = QLabel(f"当前版本: {self.current_version}")
        current_version_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #2196F3;")
        version_layout.addWidget(current_version_label)
        
        self.status_label = QLabel("正在检查更新...")
        self.status_label.setStyleSheet("font-size: 12px; color: #666;")
        version_layout.addWidget(self.status_label)
        
        version_frame.setLayout(version_layout)
        layout.addWidget(version_frame)
        
        # 下载路径选择区域
        path_frame = QFrame()
        path_frame.setFrameStyle(QFrame.Shape.Box)
        path_layout = QVBoxLayout()
        
        path_title_label = QLabel("下载保存路径:")
        path_title_label.setStyleSheet("font-size: 12px; font-weight: bold;")
        path_layout.addWidget(path_title_label)
        
        path_selection_layout = QHBoxLayout()
        
        self.path_label = QLabel(self.download_path)
        self.path_label.setStyleSheet("""
            QLabel {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 6px;
                background-color: white;
                font-size: 11px;
            }
        """)
        self.path_label.setWordWrap(True)
        path_selection_layout.addWidget(self.path_label, 1)
        
        self.browse_btn = QPushButton("浏览...")
        self.browse_btn.setStyleSheet(self.get_button_style("#2196F3"))
        self.browse_btn.setFixedWidth(80)
        self.browse_btn.clicked.connect(self.browse_download_path)
        path_selection_layout.addWidget(self.browse_btn)
        
        path_layout.addLayout(path_selection_layout)
        path_frame.setLayout(path_layout)
        layout.addWidget(path_frame)
        
        # 可用版本列表
        versions_label = QLabel("可用版本:")
        versions_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        layout.addWidget(versions_label)
        
        self.versions_list = QListWidget()
        self.versions_list.setStyleSheet("""
            QListWidget {
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
                font-size: 12px;
            }
            QListWidget::item {
                padding: 8px;
                border-bottom: 1px solid #eee;
            }
            QListWidget::item:selected {
                background-color: #e3f2fd;
                color: #1976d2;
            }
            QListWidget::item:hover {
                background-color: #f5f5f5;
            }
        """)
        layout.addWidget(self.versions_list)
        
        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #ddd;
                border-radius: 4px;
                text-align: center;
                font-size: 12px;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
                border-radius: 3px;
            }
        """)
        layout.addWidget(self.progress_bar)
        
        # 日志输出
        log_label = QLabel("操作日志:")
        log_label.setStyleSheet("font-size: 12px; font-weight: bold;")
        layout.addWidget(log_label)
        
        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(100)
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: #f9f9f9;
                font-family: Consolas, monospace;
                font-size: 10px;
            }
        """)
        layout.addWidget(self.log_text)
        
        # 按钮区域
        button_layout = QHBoxLayout()
        
        self.refresh_btn = QPushButton("刷新列表")
        self.refresh_btn.setStyleSheet(self.get_button_style("#757575"))
        self.refresh_btn.clicked.connect(self.load_versions)
        button_layout.addWidget(self.refresh_btn)
        
        button_layout.addStretch()
        
        self.download_btn = QPushButton("下载选中版本")
        self.download_btn.setStyleSheet(self.get_button_style("#4CAF50"))
        self.download_btn.clicked.connect(self.download_selected)
        self.download_btn.setEnabled(False)
        button_layout.addWidget(self.download_btn)
        
        self.cancel_btn = QPushButton("取消")
        self.cancel_btn.setStyleSheet(self.get_button_style("#f44336"))
        self.cancel_btn.clicked.connect(self.close)
        button_layout.addWidget(self.cancel_btn)
        
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
        # 连接信号
        self.versions_list.itemSelectionChanged.connect(self.on_selection_changed)
    
    def get_button_style(self, color):
        return f"""
            QPushButton {{
                background-color: {color};
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 12px;
            }}
            QPushButton:hover {{
                background-color: {color}dd;
            }}
            QPushButton:disabled {{
                background-color: #ccc;
                color: #666;
            }}
        """
    
    def browse_download_path(self):
        """浏览并选择下载保存路径"""
        selected_path = QFileDialog.getExistingDirectory(
            self, 
            "选择下载保存路径", 
            self.download_path,
            QFileDialog.Option.ShowDirsOnly
        )
        
        if selected_path:
            self.download_path = selected_path
            self.path_label.setText(self.download_path)
            self.log_message(f"下载路径已更改为: {self.download_path}")
            # 保存配置，记住下载路径
            config = load_config()
            config['download_path'] = self.download_path
            save_config(config)
    
    def log_message(self, message):
        """添加日志消息"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")
    
    def load_versions(self):
        """加载可用版本列表"""
        self.log_message("正在检查服务器...")
        self.status_label.setText("正在检查更新...")
        self.versions_list.clear()
        self.refresh_btn.setEnabled(False)
        
        try:
            response = requests.get(f"{self.server_url}/versions", timeout=10)
            response.raise_for_status()
            
            data = response.json()
            versions = data.get('versions', [])
            
            if not versions:
                self.status_label.setText("服务器上没有可用版本")
                self.log_message("服务器上没有找到任何版本")
                return
            
            # 添加版本到列表
            for version_info in versions:
                filename = version_info['filename']
                size = version_info['size']
                modified = version_info['modified']
                
                # 创建列表项
                item = QListWidgetItem()
                item.setText(f"{filename}")
                item.setToolTip(f"文件大小: {self.format_size(size)}\n修改时间: {modified}")
                item.setData(Qt.ItemDataRole.UserRole, version_info)

                
                # 对比版本号逻辑
                def extract_version(filename):
                    match = re.search(r'v?(\d+\.\d+(?:\.\d+)?)', filename)
                    return match.group(1) if match else ""
                # 如果是当前版本，标记为已安装
                file_version = extract_version(filename)
                if file_version == self.current_version:
                    item.setText(f"{filename} (当前版本)")
                    item.setBackground(Qt.GlobalColor.lightGray)

                
                self.versions_list.addItem(item)
            
            self.status_label.setText(f"找到 {len(versions)} 个可用版本")
            self.log_message(f"成功加载 {len(versions)} 个版本")
            
        except requests.RequestException as e:
            error_msg = f"连接服务器失败"
            self.status_label.setText(error_msg)
            self.log_message(error_msg)
            
        except Exception as e:
            error_msg = f"获取版本列表失败: {str(e)}"
            self.status_label.setText(error_msg)
            self.log_message(error_msg)
            
        finally:
            self.refresh_btn.setEnabled(True)
    
    def format_size(self, size):
        """格式化文件大小"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} TB"
    
    def on_selection_changed(self):
        """选择改变时的处理"""
        selected_items = self.versions_list.selectedItems()
        self.download_btn.setEnabled(len(selected_items) > 0)
    
    def download_selected(self):
        """下载选中的版本"""
        selected_items = self.versions_list.selectedItems()
        if not selected_items:
            return
        
        item = selected_items[0]
        version_info = item.data(Qt.ItemDataRole.UserRole)
        filename = version_info['filename']
        
        # 检查下载路径是否存在
        if not os.path.exists(self.download_path):
            try:
                os.makedirs(self.download_path)
                self.log_message(f"创建下载目录: {self.download_path}")
            except Exception as e:
                QMessageBox.warning(self, "路径错误", f"无法创建下载目录: {str(e)}")
                return
        
        # 检查路径是否可写
        if not os.access(self.download_path, os.W_OK):
            QMessageBox.warning(self, "权限错误", "选择的下载路径没有写入权限")
            return
        
        # 检查是否是当前版本
#        if self.current_version in filename:
#            QMessageBox.information(self, "提示", "这是当前版本，无需重复下载")
#            return
        
        # 确认下载
        reply = QMessageBox.question(
            self, "确认下载", 
            f"确定要下载 {filename} 吗？\n文件大小: {self.format_size(version_info['size'])}\n保存路径: {self.download_path}",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply != QMessageBox.StandardButton.Yes:
            return
        
        # 开始下载
        download_url = f"{self.server_url}/download/{filename}"
        save_path = os.path.join(self.download_path, filename)
        
        # 检查文件是否已存在
        if os.path.exists(save_path):
            reply = QMessageBox.question(
                self, "文件已存在", 
                f"文件 {filename} 已存在，是否覆盖？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return
        
        self.log_message(f"开始下载: {filename} 到 {save_path}")
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.download_btn.setEnabled(False)
        self.browse_btn.setEnabled(False)  # 下载期间禁用路径选择
        self.cancel_btn.setText("取消下载")
        
        # 创建下载线程
        self.download_thread = DownloadThread(download_url, save_path)
        self.download_thread.progress.connect(self.progress_bar.setValue)
        self.download_thread.finished.connect(self.on_download_finished)
        self.download_thread.start()
    
    def on_download_finished(self, success, message):
        """下载完成处理"""
        self.progress_bar.setVisible(False)
        self.download_btn.setEnabled(True)
        self.browse_btn.setEnabled(True)  # 重新启用路径选择
        self.cancel_btn.setText("关闭")
        
        if success:
            self.log_message(f"下载完成！文件已保存到: {self.download_path}")
            QMessageBox.information(self, "下载完成", f"版本包已下载到:\n{self.download_path}\n\n请手动解压并替换程序文件")
        else:
            self.log_message(f"下载失败: {message}")
            QMessageBox.warning(self, "下载失败", message)
        
        self.download_thread = None
    
    def closeEvent(self, event):
        """关闭窗口时的处理"""
        if self.download_thread and self.download_thread.isRunning():
            reply = QMessageBox.question(
                self, "确认关闭", 
                "正在下载中，确定要关闭吗？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if reply == QMessageBox.StandardButton.Yes:
                self.download_thread.cancel()
                self.download_thread.wait()
                event.accept()
            else:
                event.ignore()
        else:
            event.accept()
    # 在主窗口类中修改 show_renew_box 方法



if __name__ == "__main__":
    from PyQt6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    update_box = UpdateBox()
    update_box.show()
    sys.exit(app.exec())