#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试多线程文件搜索功能
"""

import os
import sys
import time
import random
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QTimer, Qt

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from soso import FileSearchWorker, process_single_file_for_matching

def create_test_files(base_dir, num_files=1000):
    """创建测试文件"""
    print(f"创建 {num_files} 个测试文件...")
    
    if not os.path.exists(base_dir):
        os.makedirs(base_dir)
    
    # 创建一些子文件夹
    subdirs = ['folder1', 'folder2', 'folder3']
    for subdir in subdirs:
        subdir_path = os.path.join(base_dir, subdir)
        if not os.path.exists(subdir_path):
            os.makedirs(subdir_path)
    
    # 创建测试文件
    extensions = ['.jpg', '.png', '.gif', '.bmp']
    test_names = ['test', 'image', 'photo', 'pic', 'sample', 'demo']
    
    for i in range(num_files):
        # 随机选择文件夹
        if i % 4 == 0:
            folder = base_dir
        else:
            folder = os.path.join(base_dir, random.choice(subdirs))
        
        # 生成文件名
        name = random.choice(test_names)
        ext = random.choice(extensions)
        filename = f"{name}_{i:04d}{ext}"
        
        filepath = os.path.join(folder, filename)
        
        # 创建文件
        with open(filepath, 'w') as f:
            f.write(f"Test file {i}")
    
    print(f"测试文件创建完成: {base_dir}")

def test_single_thread_performance(all_files, search_names):
    """测试单线程性能"""
    print("测试单线程搜索性能...")
    start_time = time.time()
    
    matched_files = []
    for file_path in all_files:
        result = process_single_file_for_matching(file_path, search_names)
        if result:
            matched_files.append(result)
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"单线程搜索完成:")
    print(f"  - 处理文件数: {len(all_files)}")
    print(f"  - 找到匹配: {len(matched_files)}")
    print(f"  - 耗时: {duration:.2f} 秒")
    print(f"  - 速度: {len(all_files)/duration:.0f} 文件/秒")
    
    return matched_files, duration

def test_multithread_performance(all_files, search_names):
    """测试多线程性能"""
    print("测试多线程搜索性能...")
    
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
    
    start_time = time.time()
    matched_files = []
    search_completed = False
    
    def on_search_completed(files, names):
        nonlocal matched_files, search_completed
        print(f"[DEBUG] 搜索完成回调: 收到 {len(files)} 个匹配文件, {len(names)} 个匹配名称")
        matched_files = files
        search_completed = True
    
    def on_progress_updated(progress, current_file):
        if progress % 20 == 0:  # 只显示每20%的进度
            print(f"进度: {progress}% - {current_file}")
    
    # 创建多线程搜索器
    worker = FileSearchWorker(all_files, search_names, max_workers=4)
    worker.search_completed.connect(on_search_completed, Qt.ConnectionType.QueuedConnection)
    worker.progress_updated.connect(on_progress_updated, Qt.ConnectionType.QueuedConnection)

    print(f"[DEBUG] 创建工作线程，文件数: {len(all_files)}, 搜索名称: {search_names}")

    # 启动搜索
    worker.start()
    print(f"[DEBUG] 工作线程已启动")

    # 等待完成
    worker.wait()  # 等待线程完成

    # 处理所有待处理的事件，确保信号被处理
    for _ in range(100):
        app.processEvents()
        if search_completed:
            break

    print(f"[DEBUG] 等待结束，search_completed: {search_completed}, worker.isRunning(): {worker.isRunning()}")
    
    end_time = time.time()
    duration = end_time - start_time
    
    print(f"多线程搜索完成:")
    print(f"  - 处理文件数: {len(all_files)}")
    print(f"  - 找到匹配: {len(matched_files)}")
    print(f"  - 耗时: {duration:.2f} 秒")
    print(f"  - 速度: {len(all_files)/duration:.0f} 文件/秒")
    
    return matched_files, duration

def main():
    """主测试函数"""
    print("=== 多线程文件搜索性能测试 ===")
    
    # 测试参数
    test_dir = "test_multithread_files"
    num_files = 5000  # 创建5000个测试文件
    search_names = ['test', 'image', 'photo']
    
    # 创建测试文件
    create_test_files(test_dir, num_files)
    
    # 获取所有测试文件
    all_files = []
    extensions = ('.jpg', '.png', '.gif', '.bmp')
    
    for root, _, files in os.walk(test_dir):
        for file in files:
            if file.lower().endswith(extensions):
                full_path = os.path.join(root, file)
                all_files.append(full_path)
    
    print(f"总共找到 {len(all_files)} 个图片文件")
    
    # 测试单线程性能
    single_matches, single_time = test_single_thread_performance(all_files, search_names)
    
    print("\n" + "="*50 + "\n")
    
    # 测试多线程性能
    multi_matches, multi_time = test_multithread_performance(all_files, search_names)
    
    print("\n" + "="*50)
    print("性能对比:")
    print(f"单线程耗时: {single_time:.2f} 秒")
    print(f"多线程耗时: {multi_time:.2f} 秒")
    if multi_time > 0:
        speedup = single_time / multi_time
        print(f"性能提升: {speedup:.2f}x")
    
    # 验证结果一致性
    if len(single_matches) == len(multi_matches):
        print("✅ 搜索结果一致")
    else:
        print("❌ 搜索结果不一致")
        print(f"单线程找到: {len(single_matches)} 个")
        print(f"多线程找到: {len(multi_matches)} 个")
    
    # 清理测试文件
    import shutil
    try:
        shutil.rmtree(test_dir)
        print(f"清理测试文件: {test_dir}")
    except:
        print(f"无法清理测试文件: {test_dir}")

if __name__ == "__main__":
    main()
