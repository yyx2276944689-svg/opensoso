#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
测试文件冲突处理功能
"""

import sys
import os
from PyQt6.QtWidgets import QApplication
from soso import FileConflictDialog

def test_conflict_dialog():
    """测试文件冲突对话框"""
    app = QApplication(sys.argv)
    
    # 创建文件冲突对话框
    dialog = FileConflictDialog(None, "test1.jpg", "test_images")
    
    print("显示文件冲突对话框...")
    print("文件名: test1.jpg")
    print("源文件夹: test_images")
    print("请在对话框中选择处理方式...")
    
    result = dialog.exec()
    remember = dialog.remember_choice.isChecked()
    
    print(f"用户选择: {result}")
    print(f"记住选择: {remember}")
    
    if result == 0:
        print("用户选择: 跳过此文件")
    elif result == 1:
        print("用户选择: 覆盖原有文件")
    elif result == 2:
        print("用户选择: 重命名保存")
    else:
        print("用户取消了操作")
    
    app.quit()

if __name__ == "__main__":
    test_conflict_dialog()
