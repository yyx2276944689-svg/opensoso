#!/usr/bin/env python3
"""
最终测试文件格式筛选功能
"""

import sys
import os
import tempfile
from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import QTimer

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(__file__))

def test_final():
    """最终测试"""
    app = QApplication(sys.argv)
    
    # 创建临时测试文件夹
    with tempfile.TemporaryDirectory() as temp_dir:
        # 创建不同格式的测试文件
        test_files = ['doc1.txt', 'img1.jpg', 'img2.png', 'code.py', 'data.json']
        for filename in test_files:
            with open(os.path.join(temp_dir, filename), 'w') as f:
                f.write('test content')
        
        print(f"测试文件夹: {temp_dir}")
        print(f"测试文件: {test_files}")
        
        try:
            from getname import GetNameWindow
            
            # 创建窗口并显示
            window = GetNameWindow()
            window.show()
            
            # 设置文件夹并加载
            window.folder_path = temp_dir
            window.folder_entry.setText(temp_dir)
            window.load_files()
            
            # 检查结果
            print(f"检测到的文件类型: {window.suffixes}")
            print(f"type_frame可见: {window.type_frame.isVisible()}")
            print(f"复选框数量: {len(window.type_checkboxes)}")
            print(f"布局子控件数: {window.type_checkboxes_layout.count()}")
            
            # 检查每个复选框
            for i, cb in enumerate(window.type_checkboxes):
                print(f"复选框 {i}: {cb.text()}, 选中: {cb.isChecked()}, 可见: {cb.isVisible()}")
            
            # 设置定时器自动关闭
            def close_window():
                window.close()
                app.quit()
            
            timer = QTimer()
            timer.timeout.connect(close_window)
            timer.start(3000)  # 3秒后关闭
            
            print("窗口将在3秒后自动关闭...")
            app.exec()
            
            return True
            
        except Exception as e:
            print(f"测试失败: {e}")
            import traceback
            traceback.print_exc()
            return False

if __name__ == "__main__":
    success = test_final()
    if success:
        print("✅ 最终测试成功")
    else:
        print("❌ 最终测试失败")
