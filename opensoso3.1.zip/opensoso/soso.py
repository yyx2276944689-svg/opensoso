import os
import shutil
import json
from openpyxl import Workbook
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                            QHBoxLayout, QPushButton, QLineEdit, QTextEdit,
                            QLabel, QFileDialog, QMessageBox, QScrollArea,
                            QDialog, QCheckBox, QRadioButton, QButtonGroup,
                            QProgressBar, QSizePolicy)
from PyQt6.QtCore import Qt, QSize, QEvent, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QIcon, QTextCursor, QKeySequence, QKeyEvent
from game2 import MemoryGame, GameManager
from renew_box import UpdateBox
import sys
import multiprocessing
import unicodedata
from game import SudokuWindow
import base64
import datetime
import re
from concurrent.futures import ThreadPoolExecutor, as_completed


CONFIG_FILE = "last_dirs.json"
PASSWORD_FILE = "password.json"
SETTINGS_FILE = "soso_settings.json" # 新增：设置文件

def load_last_dirs():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                # 确保返回的是字符串类型
                return {
                    "image_dir": str(data.get("image_dir", "")),
                    "output_dir": str(data.get("output_dir", ""))
                }
            except:
                return {"image_dir": "", "output_dir": ""}
    return {"image_dir": "", "output_dir": ""}

def save_last_dirs(image_dir, output_dir):
    # 确保保存的是字符串类型
    data = {
        "image_dir": str(image_dir),
        "output_dir": str(output_dir)
    }
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f)

def load_password():
    if os.path.exists(PASSWORD_FILE):
        with open(PASSWORD_FILE, "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                if data.get("password"):
                    data["password"] = base64.b64decode(data["password"]).decode('utf-8')
                return data
            except:
                return {"password": "", "remember": False}
    return {"password": "", "remember": False}

def save_password(password, remember):
    encoded = base64.b64encode(password.encode('utf-8')).decode('utf-8')
    with open(PASSWORD_FILE, "w", encoding="utf-8") as f:
        json.dump({"password": encoded, "remember": remember}, f)

def load_soso_settings():
    """从文件加载soso工具的设置"""
    if os.path.exists(SETTINGS_FILE):
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except:
                pass # 忽略加载失败，返回默认设置
    return {
        'operation': 'copy',  # 'copy' 或 'move'
        'search_subfolders': False,
        'add_suffix': True,  # 默认开启序号后缀
    }

def save_soso_settings(settings):
    """将soso工具的设置保存到文件"""
    with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(settings, f, indent=4, ensure_ascii=False)

def process_single_file_for_matching(file_path, search_names):
    """处理单个文件进行匹配"""
    try:
        if not os.path.exists(file_path):
            return None
            
        filename = os.path.basename(file_path)
        filename_lower = unicodedata.normalize('NFKC', filename.strip().lower())
        
        for search_name in search_names:
            if '-' in search_name and search_name.split('-')[-1].isdigit():
                if search_name == filename_lower:
                    return file_path, search_name
            else:
                if search_name in filename_lower:
                    return file_path, search_name
        return None
    except Exception as e:
        print(f"Error processing file {file_path}: {str(e)}")
        return None



# 将类定义移动到实例化之前
class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.setFixedSize(500, 450)  # 保持较大的窗口尺寸
        self.setStyleSheet("""
            QDialog {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QCheckBox, QRadioButton, QLabel {
                /* 移除所有自定义字体样式，让其使用系统默认字体 */
            }
        """)

        # 使用主布局
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(30, 30, 30, 30)
        main_layout.setSpacing(20)

        # 操作方式
        operation_label = QLabel("操作方式：")
        main_layout.addWidget(operation_label)

        self.operation_group = QButtonGroup(self)
        self.copy_radio = QRadioButton("复制文件")
        self.move_radio = QRadioButton("移动文件")
        
        if parent.settings['operation'] == 'copy':
            self.copy_radio.setChecked(True)
        else:
            self.move_radio.setChecked(True)

        self.operation_group.addButton(self.copy_radio)
        self.operation_group.addButton(self.move_radio)

        main_layout.addWidget(self.copy_radio)
        main_layout.addWidget(self.move_radio)

        # 搜索选项
        search_label = QLabel("搜索选项：")
        main_layout.addWidget(search_label)

        self.search_subfolders = QCheckBox("搜索子文件夹")
        self.search_subfolders.setChecked(parent.settings['search_subfolders'])
        main_layout.addWidget(self.search_subfolders)

        # 重命名选项
        rename_label = QLabel("重命名选项：")
        main_layout.addWidget(rename_label)

        self.add_suffix = QCheckBox("添加文件名后缀")
        self.add_suffix.setChecked(parent.settings.get('add_suffix', True))
        main_layout.addWidget(self.add_suffix)

        # 添加弹性空间
        main_layout.addStretch()

        # 确定按钮
        ok_button = QPushButton("确定")
        ok_button.clicked.connect(self.accept)
        main_layout.addWidget(ok_button)

class NonScrollableTextEdit(QTextEdit):
    def wheelEvent(self, event):
        # 彻底忽略滚轮事件，使其在任何情况下都不可滚动
        event.ignore()

def process_file_batch(file_batch, search_names):
    """处理一批文件的匹配，用于多线程"""
    matched_files = []
    found_names = set()

    for file_path in file_batch:
        try:
            result = process_single_file_for_matching(file_path, search_names)
            if result:
                file_path_found, matched_name = result
                matched_files.append((file_path_found, matched_name))

                # 更新找到的名称集合
                filename_lower_for_check = unicodedata.normalize('NFKC', os.path.basename(file_path_found).strip().lower())
                for s_name in search_names:
                    if '-' in s_name and s_name.split('-')[-1].isdigit():
                        if s_name == filename_lower_for_check:
                            found_names.add(s_name)
                    else:
                        if s_name in filename_lower_for_check:
                            found_names.add(s_name)
        except Exception as e:
            print(f"Error processing file {file_path}: {str(e)}")
            continue

    return matched_files, found_names

class FileSearchWorker(QThread):
    """文件搜索工作线程"""
    progress_updated = pyqtSignal(int, str)  # 进度更新信号 (进度值, 当前文件)
    search_completed = pyqtSignal(list, set)  # 搜索完成信号 (匹配的文件列表, 找到的名称集合)
    error_occurred = pyqtSignal(str)  # 错误信号

    def __init__(self, all_files, search_names, max_workers=None):
        super().__init__()
        self.all_files = all_files
        self.search_names = search_names
        self.max_workers = max_workers or min(8, multiprocessing.cpu_count())
        self.is_cancelled = False

    def run(self):
        """执行文件搜索"""
        try:
            total_files = len(self.all_files)
            if total_files == 0:
                self.search_completed.emit([], set())
                return

            # 将文件分批处理
            batch_size = max(1, total_files // (self.max_workers * 4))  # 每个线程处理多个批次
            file_batches = []

            for i in range(0, total_files, batch_size):
                if self.is_cancelled:
                    return
                batch = self.all_files[i:i + batch_size]
                file_batches.append(batch)

            matched_files_total = []
            found_names_total = set()
            processed_files = 0

            # 使用线程池处理文件批次
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                # 提交所有批次任务
                future_to_batch = {
                    executor.submit(process_file_batch, batch, self.search_names): batch
                    for batch in file_batches
                }

                # 处理完成的任务
                for future in as_completed(future_to_batch):
                    if self.is_cancelled:
                        # 取消所有未完成的任务
                        for f in future_to_batch:
                            f.cancel()
                        return

                    try:
                        batch = future_to_batch[future]
                        matched_files, found_names = future.result()

                        # 合并结果
                        matched_files_total.extend(matched_files)
                        found_names_total.update(found_names)

                        # 更新进度
                        processed_files += len(batch)
                        progress = int((processed_files / total_files) * 100)

                        # 发送进度更新信号
                        current_file = batch[-1] if batch else ""
                        self.progress_updated.emit(progress, os.path.basename(current_file))

                    except Exception as e:
                        self.error_occurred.emit(f"处理文件批次时出错: {str(e)}")

            # 发送完成信号
            self.search_completed.emit(matched_files_total, found_names_total)

        except Exception as e:
            self.error_occurred.emit(f"文件搜索过程中出错: {str(e)}")

    def cancel(self):
        """取消搜索"""
        self.is_cancelled = True

class FileConflictDialog(QDialog):
    def __init__(self, parent=None, filename="", source_folder=""):
        super().__init__(parent)
        self.setWindowTitle("文件名冲突")
        self.setFixedSize(500, 200)
        self.setStyleSheet("""
            QDialog {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
                min-height: 30px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 提示信息
        info_label = QLabel(f"文件 '{filename}' 在输出目录中已存在。")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)

        question_label = QLabel("请选择处理方式：")
        layout.addWidget(question_label)

        # 按钮布局
        button_layout = QHBoxLayout()

        # 覆盖按钮
        self.overwrite_btn = QPushButton("覆盖原有文件")
        self.overwrite_btn.clicked.connect(lambda: self.done(1))  # 返回1表示覆盖
        button_layout.addWidget(self.overwrite_btn)

        # 重命名按钮
        self.rename_btn = QPushButton("重命名保存")
        self.rename_btn.clicked.connect(lambda: self.done(2))  # 返回2表示重命名
        button_layout.addWidget(self.rename_btn)

        # 跳过按钮
        self.skip_btn = QPushButton("跳过此文件")
        self.skip_btn.clicked.connect(lambda: self.done(0))  # 返回0表示跳过
        button_layout.addWidget(self.skip_btn)

        layout.addLayout(button_layout)

        # 记住选择的复选框
        self.remember_choice = QCheckBox("对所有冲突文件应用此选择")
        layout.addWidget(self.remember_choice)

class ProgressDialog(QDialog):
    # 添加取消信号
    cancelled = pyqtSignal()

    def __init__(self, parent=None, show_cancel=True):
        super().__init__(parent)
        self.setWindowTitle("处理进度")
        self.setFixedSize(400, 200 if show_cancel else 150)
        self.setStyleSheet("""
            QDialog {
                background-color: #f0f0f0;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            QProgressBar {
                border: 1px solid #ddd;
                border-radius: 4px;
                text-align: center;
                background-color: white;
            }
            QProgressBar::chunk {
                background-color: #2196F3;
            }
            QPushButton {
                background-color: #f44336;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #d32f2f;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 进度标签
        self.progress_label = QLabel("正在处理文件...")
        layout.addWidget(self.progress_label)

        # 进度条
        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(100)
        layout.addWidget(self.progress_bar)

        # 详细信息标签
        self.detail_label = QLabel("")
        layout.addWidget(self.detail_label)

        # 取消按钮（可选）
        if show_cancel:
            self.cancel_button = QPushButton("取消")
            self.cancel_button.clicked.connect(self.on_cancel_clicked)
            layout.addWidget(self.cancel_button)
        else:
            self.cancel_button = None

    def on_cancel_clicked(self):
        """处理取消按钮点击"""
        self.cancelled.emit()
        if self.cancel_button:
            self.cancel_button.setText("正在取消...")
            self.cancel_button.setEnabled(False)

    def update_progress(self, current, total, current_file=""):
        percentage = int((current / total) * 100)
        self.progress_bar.setValue(percentage)
        self.progress_label.setText(f"正在处理文件... ({current}/{total})")
        if current_file:
            self.detail_label.setText(f"当前处理: {current_file}")
        QApplication.processEvents()  # 确保UI更新

    def update_progress_direct(self, percentage, current_file=""):
        """直接更新进度百分比"""
        self.progress_bar.setValue(percentage)
        self.progress_label.setText(f"正在扫描文件... ({percentage}%)")
        if current_file:
            self.detail_label.setText(f"当前扫描: {current_file}")
        QApplication.processEvents()  # 确保UI更新

class MainWindow(QMainWindow):
    def __init__(self):
        print("[DEBUG] MainWindow created")
        super().__init__()
        self._was_maximized = False  # 记录最大化状态
        self.rename_window = None  # 保存重命名窗口引用，防止闪退
        # 初始化图片文件夹选择框列表
        self.image_folder_entries = []
        
        # 初始化设置 - 从文件加载
        self.settings = load_soso_settings()
        
        # 初始化筛选历史记录
        self.filter_history = []

        # 初始化多线程相关变量
        self.search_worker = None  # 文件搜索工作线程
        self.max_threads = min(8, multiprocessing.cpu_count())  # 最大线程数

        # 安装事件过滤器以禁用行号列表的滚轮滚动
        self.line_number_list_widget = None # 稍后初始化
        
        self.setWindowTitle("Opensoso2.8")
        self.setMinimumSize(800, 600)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
  # 关键：窗口自适应
        
        # 设置窗口图标
        icon_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QLineEdit, QTextEdit {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
                font-size: 14px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            #addButton {
                background-color: transparent;
                border: none;
                padding: 8px;
            }
            #addButton:hover {
                background-color: rgba(33, 150, 243, 0.1);
            }
            #closeButton {
                background-color: transparent;
                border: none;
                padding: 8px;
                color: #666;
            }
            #closeButton:hover {
                background-color: rgba(244, 67, 54, 0.1);
                color: #f44336;
            }
        """)

        # 创建主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 顶部工具栏
        toolbar_layout = QHBoxLayout()
        toolbar_layout.addStretch()

        # 添数独小游戏
        new_btn = QPushButton()
        icon_path = os.path.join(os.path.dirname(__file__), "renew.png")
        if os.path.exists(icon_path):
            new_btn.setIcon(QIcon(icon_path))
        new_btn.setIconSize(QSize(24, 24))
        new_btn.setFixedSize(32, 32)
        new_btn.setToolTip("数独")
        new_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        self.sudoku_window = None  # 延迟实例化
        def show_sudoku():
            if self.sudoku_window is None:
                self.sudoku_window = SudokuWindow(self)
            self.sudoku_window.show()
        new_btn.clicked.connect(show_sudoku)
        toolbar_layout.addWidget(new_btn)
        # 更新按钮
        renew_btn = QPushButton()
        renew_icon_path = os.path.join(os.path.dirname(__file__), "genxin.png")
        if os.path.exists(renew_icon_path):
            renew_btn.setIcon(QIcon(renew_icon_path))
        else:
            renew_btn.setText("下载")
        renew_btn.setIconSize(QSize(24, 24))
        renew_btn.setFixedSize(32, 32)
        renew_btn.setToolTip("检测更新")
        renew_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        def show_renew_box():
            print("[DEBUG] show_renew_box called")
            try:
                from renew_box import UpdateBox
                # 检查对象是否存在且有效
                renew_box_exists = (hasattr(self, 'renew_box') and 
                                  self.renew_box is not None and 
                                  hasattr(self.renew_box, 'isVisible'))
                
                if renew_box_exists:
                    try:
                        # 尝试访问对象，如果已被删除会抛出异常
                        is_visible = self.renew_box.isVisible()
                        if is_visible:
                            print("[DEBUG] UpdateBox already exists, raising window")
                            self.renew_box.raise_()
                            self.renew_box.activateWindow()
                            return
                        else:
                            # 窗口存在但不可见，重新显示
                            print("[DEBUG] UpdateBox exists but not visible, showing window")
                            self.renew_box.show()
                            return
                    except RuntimeError:
                        # 对象已被删除，清除引用
                        print("[DEBUG] UpdateBox object was deleted, clearing reference")
                        self.renew_box = None
                
                # 创建新的UpdateBox
                print("[DEBUG] Creating new UpdateBox")
                self.renew_box = UpdateBox()
                self.renew_box.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
                # 连接关闭信号，清除引用
                self.renew_box.destroyed.connect(lambda: setattr(self, 'renew_box', None))
                self.renew_box.show()
                
            except Exception as e:
                import traceback
                print("[ERROR] Exception in show_renew_box:", e)
                print(traceback.format_exc())
        
        renew_btn.clicked.connect(show_renew_box)
        toolbar_layout.addWidget(renew_btn)


               # 新增：获取当前文件夹所有文件名按钮
        getname_btn = QPushButton()
        getname_icon_path = os.path.join(os.path.dirname(__file__), "getname.png")
        if os.path.exists(getname_icon_path):
            getname_btn.setIcon(QIcon(getname_icon_path))
        else:
            getname_btn.setText("取名")
        getname_btn.setIconSize(QSize(24, 24))
        getname_btn.setFixedSize(32, 32)
        getname_btn.setToolTip("获取当前图片文件夹所有文件名")
        getname_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        def show_getname():
            try:
                from getname import GetNameWindow

                # 检查是否已有窗口实例且仍然有效
                if (hasattr(self, 'getname_window') and
                    self.getname_window is not None):
                    try:
                        # 尝试访问窗口，如果已被删除会抛出异常
                        if self.getname_window.isVisible():
                            # 窗口存在且可见，将其置于前台
                            self.getname_window.raise_()
                            self.getname_window.activateWindow()
                            return
                        else:
                            # 窗口存在但不可见，重新显示
                            self.getname_window.show()
                            return
                    except RuntimeError:
                        # 窗口对象已被删除，清除引用
                        self.getname_window = None

                # 创建新的窗口实例
                self.getname_window = GetNameWindow(self)
                # 设置窗口关闭时自动删除
                self.getname_window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
                # 连接销毁信号，清除引用
                self.getname_window.destroyed.connect(lambda: setattr(self, 'getname_window', None))
                self.getname_window.show()

            except Exception as e:
                print(f"显示获取文件名窗口时出错: {e}")
                QMessageBox.critical(self, "错误", f"无法打开获取文件名窗口：{str(e)}")
        getname_btn.clicked.connect(show_getname)
        toolbar_layout.addWidget(getname_btn)

       # 进入批量重命名按钮
        rename_btn_top = QPushButton()
        rename_icon_path = os.path.join(os.path.dirname(__file__), "cmm.png")
        if os.path.exists(rename_icon_path):
            rename_btn_top.setIcon(QIcon(rename_icon_path))
        else:
            rename_btn_top.setText("重命名")
        rename_btn_top.setIconSize(QSize(24, 24))
        rename_btn_top.setFixedSize(32, 32)
        rename_btn_top.setToolTip("进入批量重命名功能界面")
        rename_btn_top.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        rename_btn_top.clicked.connect(self.go_to_rename)
        toolbar_layout.addWidget(rename_btn_top)

 
       # 新增：历史记录按钮
        history_btn = QPushButton()
        history_icon_path = os.path.join(os.path.dirname(__file__), "history.png")
        if os.path.exists(history_icon_path):
            history_btn.setIcon(QIcon(history_icon_path))
        else:
            history_btn.setText("")
        history_btn.setIconSize(QSize(24, 24))
        history_btn.setFixedSize(32, 32)
        history_btn.setToolTip("历史记录")
        history_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        history_btn.clicked.connect(self.show_history)
        toolbar_layout.addWidget(history_btn)

        layout.addLayout(toolbar_layout)
               # 添加撤销按钮
        undo_btn = QPushButton()
        icon_path = os.path.join(os.path.dirname(__file__), "testround.png")
        if os.path.exists(icon_path):
            undo_btn.setIcon(QIcon(icon_path))
        undo_btn.setIconSize(QSize(24, 24))
        undo_btn.setFixedSize(32, 32)
        undo_btn.setToolTip("点击撤销上一次的筛选操作")
        undo_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        undo_btn.clicked.connect(self.undo_filter)
        toolbar_layout.addWidget(undo_btn)

        # 设置按钮
        setup_btn = QPushButton()
        icon_path = os.path.join(os.path.dirname(__file__), "setup.png")
        if os.path.exists(icon_path):
            setup_btn.setIcon(QIcon(icon_path))
        setup_btn.setIconSize(QSize(24, 24))
        setup_btn.setFixedSize(32, 32)
        setup_btn.setToolTip("点击此处可以设置文件处理的相关选项，如复制/移动模式、是否搜索子文件夹等")
        setup_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
        """)
        setup_btn.clicked.connect(self.show_settings)
        toolbar_layout.addWidget(setup_btn)

 
        

        # 创建图片文件夹选择区域的容器
        self.image_folders_container = QWidget()
        self.image_folders_layout = QVBoxLayout(self.image_folders_container)
        self.image_folders_layout.setSpacing(10)
        layout.addWidget(self.image_folders_container)

        # 添加第一个图片文件夹选择区域
        self.add_image_folder_selection()

        # 输出文件夹选择
        output_folder_layout = QHBoxLayout()
        self.output_folder_entry = QLineEdit()
        self.output_folder_entry.setPlaceholderText("选择输出文件夹...")
        output_folder_btn = QPushButton("选择文件夹")
        output_folder_btn.setToolTip("点击选择筛选后文件的保存位置")
        output_folder_btn.clicked.connect(self.select_output_folder)
        output_folder_layout.addWidget(QLabel("输出文件夹:"))
        output_folder_layout.addWidget(self.output_folder_entry)
        output_folder_layout.addWidget(output_folder_btn)
        layout.addLayout(output_folder_layout)

        # 名称输入区域
        name_input_label_layout = QHBoxLayout()
        name_input_label = QLabel("输入筛选名称'回车分隔'：")
        name_input_label_layout.addWidget(name_input_label)
        # 新增：右侧动态描述标签
        self.settings_desc_label = QLabel()
        self.settings_desc_label.setStyleSheet("font-size: 14px; color: #1976D2;")
        self.settings_desc_label.setMinimumHeight(24)
        name_input_label_layout.addWidget(self.settings_desc_label)
        name_input_label_layout.addStretch()
        layout.addLayout(name_input_label_layout)
        self.update_settings_desc_label()

        name_input_layout = QHBoxLayout()
        # 创建行数列表
        self.line_number_list = NonScrollableTextEdit()
        self.line_number_list.setReadOnly(True)
        self.line_number_list.setMaximumWidth(50)
        self.line_number_list.setMinimumWidth(40)
        self.line_number_list.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.line_number_list.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.line_number_list.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        font = QFont("Consolas", 14)
        self.line_number_list.setFont(font)
        self.line_number_list.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        self.line_number_list.setStyleSheet("""
            QTextEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                color: #888; /* 将行号颜色设置为灰色 */
                /* 保持和右侧输入框一样的垂直内边距以对齐 */
                padding-top: 8px;
                padding-bottom: 8px;
                padding-left: 4px;
                padding-right: 4px;
                font-size: 14px;
                background-color: #f8f8f8;
            }
        """)
        # 在创建后立即安装事件过滤器
        self.line_number_list.installEventFilter(self)
        name_input_layout.addWidget(self.line_number_list)
        # 创建名称输入框
        self.name_input_entry = QTextEdit()
        self.name_input_entry.setPlaceholderText("在此输入要筛选的名称...")
        self.name_input_entry.setMinimumHeight(150)
        self.name_input_entry.setFont(font)
        self.name_input_entry.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        self.name_input_entry.textChanged.connect(self.on_text_changed)
        # 恢复单向滚动连接
        self.name_input_entry.verticalScrollBar().valueChanged.connect(
            self.line_number_list.verticalScrollBar().setValue
        )
        # 安装事件过滤器来处理粘贴
        self.name_input_entry.installEventFilter(self)
        name_input_layout.addWidget(self.name_input_entry)
        layout.addLayout(name_input_layout)

        # 执行按钮
        filter_btn = QPushButton("执行筛选")
        filter_btn.setMinimumHeight(40)
        filter_btn.setToolTip("点击开始执行文件筛选操作")
        filter_btn.clicked.connect(self.filter_images)
        layout.addWidget(filter_btn)

        
        # 加载上次的目录
        last_dirs = load_last_dirs()
        if self.image_folder_entries:
            self.image_folder_entries[0].setText(last_dirs.get("image_dir", ""))
        self.output_folder_entry.setText(last_dirs.get("output_dir", ""))

        # 保存设置到文件
        save_soso_settings(self.settings)

    def add_image_folder_selection(self):
        folder_widget = QWidget()
        folder_layout = QHBoxLayout(folder_widget)
        folder_layout.setContentsMargins(0, 0, 0, 0)

        # 创建文件夹选择区域
        folder_entry = QLineEdit()
        folder_entry.setPlaceholderText("选择图片文件夹...")
        folder_btn = QPushButton("选择文件夹")
        folder_btn.setToolTip("点击选择包含图片的文件夹")
        folder_btn.clicked.connect(lambda: self.select_image_folder(folder_entry))

        # 创建加号按钮
        add_btn = QPushButton()
        add_btn.setObjectName("addButton")
        icon_path = os.path.join(os.path.dirname(__file__), "jia1.png")
        if os.path.exists(icon_path):
            add_btn.setIcon(QIcon(icon_path))
        add_btn.setIconSize(QSize(25, 25))
        btn_size = folder_btn.sizeHint()
        add_btn.setFixedSize(btn_size.width() // 2, btn_size.height())
        add_btn.setToolTip("点击添加新的图片文件夹选择框")
        add_btn.clicked.connect(self.add_image_folder_selection)

        # 添加到布局
        folder_layout.addWidget(QLabel("图片文件夹:"))
        folder_layout.addWidget(folder_entry)
        folder_layout.addWidget(folder_btn)
        folder_layout.addWidget(add_btn)

        # 如果不是第一个文件夹选择框，添加关闭按钮
        if len(self.image_folder_entries) > 0:
            close_btn = QPushButton("X")
            close_btn.setObjectName("closeButton")
            close_btn.setFixedSize(btn_size.height() * 2, btn_size.height() * 2)
            close_btn.setFont(QFont("Arial", 16, QFont.Weight.Bold))
            close_btn.setToolTip("点击移除当前图片文件夹选择框")
            close_btn.clicked.connect(lambda: self.remove_folder_selection(folder_widget, folder_entry))
            folder_layout.addWidget(close_btn)

        # 添加到容器
        self.image_folders_layout.addWidget(folder_widget)
        self.image_folder_entries.append(folder_entry)

        # 更新设置
        self.update_settings_for_folders()

    def update_settings_for_folders(self):
        """更新设置以匹配当前文件夹数量"""
        # 保存设置
        save_soso_settings(self.settings)

    def remove_folder_selection(self, widget, entry):
        # 确保至少保留一个文件夹选择框
        if len(self.image_folder_entries) <= 1:
            QMessageBox.warning(self, "警告", "至少需要保留一个图片文件夹！")
            return

        # 从列表中移除
        self.image_folder_entries.remove(entry)
        # 从布局中移除
        self.image_folders_layout.removeWidget(widget)
        # 删除部件
        widget.deleteLater()
        # 更新所有图片文件夹的路径
        image_dirs = [entry.text() for entry in self.image_folder_entries if entry.text()]
        save_last_dirs(image_dirs[0] if image_dirs else "", self.output_folder_entry.text())
        # 更新设置
        self.update_settings_for_folders()

    def select_image_folder(self, entry_widget):
        folder_path = QFileDialog.getExistingDirectory(self, "选择图片文件夹", 
                                                     entry_widget.text())
        if folder_path:
            entry_widget.setText(folder_path)
            # 更新所有图片文件夹的路径
            image_dirs = [entry.text() for entry in self.image_folder_entries if entry.text()]
            save_last_dirs(image_dirs[0] if image_dirs else "", self.output_folder_entry.text())

    def select_output_folder(self):
        folder_path = QFileDialog.getExistingDirectory(self, "选择输出文件夹", 
                                                     self.output_folder_entry.text())
        if folder_path:
            self.output_folder_entry.setText(folder_path)
            save_last_dirs(str(self.image_folder_entries[0].text()) if self.image_folder_entries else "", str(folder_path))

    def export_not_found_to_excel(self, not_found_list, output_dir):
        if not not_found_list:
            QMessageBox.information(self, "导出未找到名称", "所有名称都已找到，无需导出。")
            return
        file_path = os.path.join(output_dir, "未找到名称.xlsx")
        wb = Workbook()
        ws = wb.active
        ws.title = "未找到名称"
        for idx, name in enumerate(not_found_list, 1):
            ws.cell(row=idx, column=1, value=name)
        wb.save(file_path)
        QMessageBox.information(self, "导出成功", f"未找到名称已导出至:\n{file_path}")

    def filter_images(self):
        # 获取所有图片文件夹路径
        image_folders = [entry.text() for entry in self.image_folder_entries if entry.text()]
        output_folder = self.output_folder_entry.text()
        save_last_dirs(image_folders[0] if image_folders else "", output_folder)

        search_names_input = self.name_input_entry.toPlainText().strip()

        # --- 优化后的搜索名称解析逻辑：仅使用回车作为分隔符 ---
        search_names = []
        lines = search_names_input.splitlines()
        for line in lines:
            cleaned_name = unicodedata.normalize('NFKC', line.strip().lower())
            if cleaned_name:
                search_names.append(cleaned_name)

        # 检查重复名称
        name_occurrence = {}
        for idx, name in enumerate(search_names):
            if name in name_occurrence:
                name_occurrence[name].append(idx + 1)
            else:
                name_occurrence[name] = [idx + 1]

        duplicates = {name: positions for name, positions in name_occurrence.items() if len(positions) > 1}

        if duplicates:
            duplicate_info = "\n".join(f"{name} 出现在第 {', '.join(map(str, positions))} 行" 
                                     for name, positions in duplicates.items())
            QMessageBox.critical(self, "重复名称提示", 
                               f"检测到以下重复名称，请修改后再筛选：\n\n{duplicate_info}")
            return

        if not image_folders or not output_folder or not search_names:
            QMessageBox.critical(self, "错误", "请设置图片文件夹、输出文件夹和输入筛选名称！")
            return

        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        extensions = ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp')

        # 获取所有图片文件
        all_potential_image_files = []
        for image_folder in image_folders:
            if self.settings['search_subfolders']:
                for root, _, files in os.walk(image_folder):
                    for file in files:
                        if file.lower().endswith(extensions):
                            full_path = os.path.join(root, file)
                            all_potential_image_files.append(full_path)
            else:
                for file in os.listdir(image_folder):
                    if file.lower().endswith(extensions):
                        full_path = os.path.join(image_folder, file)
                        all_potential_image_files.append(full_path)

        total_scan_items = len(all_potential_image_files)

        # 创建进度对话框（带取消按钮）
        progress_dialog = ProgressDialog(self, show_cancel=True)
        progress_dialog.show()

        TOTAL_PROGRESS_MAX = 1000
        SCAN_WEIGHT = 0.5
        PROCESS_WEIGHT = 0.5

        progress_dialog.progress_bar.setMaximum(TOTAL_PROGRESS_MAX)

        overall_current_progress_value = 0

        # Phase 1: 图片文件匹配 (多线程扫描)
        matched_files_info = []
        found_names_set = set()
        search_cancelled = False

        if total_scan_items > 0:
            # 创建文件搜索工作线程
            max_workers = min(8, multiprocessing.cpu_count())  # 限制最大线程数
            search_worker = FileSearchWorker(all_potential_image_files, search_names, max_workers)

            # 连接信号
            def on_progress_updated(progress, current_file):
                nonlocal overall_current_progress_value
                # 将搜索进度映射到总进度的扫描部分
                scan_progress = (progress / 100) * SCAN_WEIGHT * TOTAL_PROGRESS_MAX
                overall_current_progress_value = scan_progress
                progress_dialog.progress_bar.setValue(int(overall_current_progress_value))
                progress_dialog.progress_label.setText(f"正在扫描文件... ({progress}%)")
                progress_dialog.detail_label.setText(f"当前扫描: {current_file}")
                QApplication.processEvents()

            def on_search_completed(matched_files, found_names):
                nonlocal matched_files_info, found_names_set, overall_current_progress_value
                # matched_files 已经是 [(file_path, matched_name), ...] 的格式
                # 转换为 [(file_path, ""), ...] 的格式以匹配原有逻辑
                matched_files_info = [(file_path, "") for file_path, matched_name in matched_files]
                found_names_set = found_names
                # 确保扫描阶段进度条达到SCAN_WEIGHT的最终值
                overall_current_progress_value = SCAN_WEIGHT * TOTAL_PROGRESS_MAX
                progress_dialog.progress_bar.setValue(int(overall_current_progress_value))
                progress_dialog.progress_label.setText("文件扫描完成")
                QApplication.processEvents()

            def on_search_error(error_msg):
                nonlocal search_cancelled
                search_cancelled = True
                QMessageBox.critical(self, "搜索错误", f"文件搜索过程中出现错误：\n{error_msg}")

            def on_search_cancelled():
                nonlocal search_cancelled
                search_cancelled = True
                search_worker.cancel()
                progress_dialog.close()
                QMessageBox.information(self, "已取消", "文件搜索已被用户取消。")
                return

            # 连接信号槽（使用队列连接确保跨线程信号正常工作）
            search_worker.progress_updated.connect(on_progress_updated, Qt.ConnectionType.QueuedConnection)
            search_worker.search_completed.connect(on_search_completed, Qt.ConnectionType.QueuedConnection)
            search_worker.error_occurred.connect(on_search_error, Qt.ConnectionType.QueuedConnection)
            progress_dialog.cancelled.connect(on_search_cancelled)

            # 启动搜索线程
            search_worker.start()

            # 等待搜索完成
            search_worker.wait()  # 等待线程完成

            # 处理所有待处理的事件，确保信号被处理
            for _ in range(100):
                QApplication.processEvents()
                if search_cancelled:
                    break

            # 如果被取消，直接返回
            if search_cancelled:
                return
        else:
            # 没有文件需要扫描
            overall_current_progress_value = SCAN_WEIGHT * TOTAL_PROGRESS_MAX
            progress_dialog.progress_bar.setValue(int(overall_current_progress_value))
            QApplication.processEvents()

        # Phase 2: 文件操作 (复制/移动)
        total_matched_files = len(matched_files_info)

        found_files = []
        error_files = []
        filename_count = {}
        duplicate_files = set()
        current_operations = []

        # 文件冲突处理选择：0=跳过, 1=覆盖, 2=重命名, None=每次询问
        conflict_choice = None
        remember_choice = False
        process_cancelled = False

        # 为文件处理阶段添加取消处理
        def on_process_cancelled():
            nonlocal process_cancelled
            process_cancelled = True
            progress_dialog.close()
            QMessageBox.information(self, "已取消", "文件处理已被用户取消。")

        # 重新连接取消信号（因为搜索阶段可能已经断开连接）
        try:
            progress_dialog.cancelled.disconnect()
        except:
            pass
        progress_dialog.cancelled.connect(on_process_cancelled)

        # 重新启用取消按钮（如果有的话）
        if hasattr(progress_dialog, 'cancel_button') and progress_dialog.cancel_button:
            progress_dialog.cancel_button.setText("取消")
            progress_dialog.cancel_button.setEnabled(True)

        if total_matched_files > 0: # 避免除以零
            for original_file_path, _ in matched_files_info:
                # 检查是否被取消
                if process_cancelled:
                    return

                try:
                    if not os.path.exists(original_file_path):
                        error_files.append(f"{os.path.basename(original_file_path)}: 源文件不存在")
                        # 即使失败，也按比例推进进度
                        overall_current_progress_value += (PROCESS_WEIGHT * TOTAL_PROGRESS_MAX) / total_matched_files
                        progress_dialog.progress_bar.setValue(int(overall_current_progress_value))
                        progress_dialog.detail_label.setText(f"当前处理: {os.path.basename(original_file_path)} (文件缺失)")
                        QApplication.processEvents()
                        continue

                    _, ext = os.path.splitext(os.path.basename(original_file_path))
                    base_name = os.path.splitext(os.path.basename(original_file_path))[0]

                    if base_name in filename_count:
                        filename_count[base_name] += 1
                        duplicate_files.add(base_name)
                    else:
                        filename_count[base_name] = 1

                    if self.settings['add_suffix'] and base_name in duplicate_files:
                        source_dir = os.path.basename(os.path.dirname(original_file_path))
                        target_filename = f"{base_name}-{source_dir}{ext}"
                    else:
                        target_filename = os.path.basename(original_file_path)

                    target_path = os.path.join(output_folder, target_filename)

                    # 检查文件是否已存在
                    if os.path.exists(target_path):
                        # 如果还没有记住选择，或者需要每次询问
                        if not remember_choice:
                            # 暂时隐藏进度对话框
                            progress_dialog.hide()

                            # 显示文件冲突对话框
                            source_folder = os.path.basename(os.path.dirname(original_file_path))
                            conflict_dialog = FileConflictDialog(self, target_filename, source_folder)
                            result = conflict_dialog.exec()

                            # 检查是否记住选择
                            if conflict_dialog.remember_choice.isChecked():
                                remember_choice = True
                                conflict_choice = result

                            # 重新显示进度对话框
                            progress_dialog.show()
                        else:
                            # 使用记住的选择
                            result = conflict_choice

                        # 根据用户选择处理文件冲突
                        if result == 0:  # 跳过
                            # 更新进度但不处理文件
                            overall_current_progress_value += (PROCESS_WEIGHT * TOTAL_PROGRESS_MAX) / total_matched_files
                            progress_dialog.progress_bar.setValue(int(overall_current_progress_value))
                            progress_dialog.detail_label.setText(f"当前处理: {os.path.basename(original_file_path)} (已跳过)")
                            QApplication.processEvents()
                            # 检查是否被取消
                            if process_cancelled:
                                return
                            continue
                        elif result == 1:  # 覆盖
                            try:
                                os.remove(target_path)
                            except Exception:
                                pass
                        elif result == 2:  # 重命名
                            # 生成新的文件名，在原文件名后添加源文件夹名作为后缀
                            source_folder_name = os.path.basename(os.path.dirname(original_file_path))
                            name_without_ext = os.path.splitext(target_filename)[0]
                            file_ext = os.path.splitext(target_filename)[1]

                            # 生成新的文件名
                            counter = 1
                            while True:
                                if counter == 1:
                                    new_filename = f"{name_without_ext}-{source_folder_name}{file_ext}"
                                else:
                                    new_filename = f"{name_without_ext}-{source_folder_name}_{counter}{file_ext}"

                                new_target_path = os.path.join(output_folder, new_filename)
                                if not os.path.exists(new_target_path):
                                    target_path = new_target_path
                                    target_filename = new_filename
                                    break

                                counter += 1
                                if counter > 1000:  # 防止无限循环
                                    error_files.append(f"{os.path.basename(original_file_path)}: 无法生成唯一文件名")
                                    break

                    # 执行文件操作
                    if self.settings['operation'] == 'copy':
                        shutil.copy2(original_file_path, target_path)
                    else:
                        shutil.move(original_file_path, target_path)
                    found_files.append((target_filename, original_file_path))

                    current_operations.append((original_file_path, target_path, self.settings['operation']))

                    # 更新处理进度
                    overall_current_progress_value += (PROCESS_WEIGHT * TOTAL_PROGRESS_MAX) / total_matched_files
                    progress_dialog.progress_bar.setValue(int(overall_current_progress_value))
                    progress_dialog.progress_label.setText(f"正在处理文件... ({int(overall_current_progress_value / TOTAL_PROGRESS_MAX * 100)}%)")
                    progress_dialog.detail_label.setText(f"当前处理: {os.path.basename(original_file_path)}")
                    QApplication.processEvents()

                    # 检查是否被取消
                    if process_cancelled:
                        return

                except Exception as e:
                    error_files.append(f"{os.path.basename(original_file_path)}: {str(e)}")
                    # 即使处理失败，也按比例推进进度
                    overall_current_progress_value += (PROCESS_WEIGHT * TOTAL_PROGRESS_MAX) / total_matched_files
                    progress_dialog.progress_bar.setValue(int(overall_current_progress_value))
                    progress_dialog.progress_label.setText(f"正在处理文件... ({int(overall_current_progress_value / TOTAL_PROGRESS_MAX * 100)}%) (有失败)")
                    progress_dialog.detail_label.setText(f"当前处理: {os.path.basename(original_file_path)} (处理失败)")
                    QApplication.processEvents()
                    continue

        # 确保进度条在所有阶段结束后达到100%
        progress_dialog.progress_bar.setValue(TOTAL_PROGRESS_MAX) 
        progress_dialog.progress_label.setText("处理完成 (100%)")
        progress_dialog.detail_label.setText("所有任务已完成。")
        QApplication.processEvents()
        
        if current_operations:
            self.filter_history.append(current_operations)

        # 保存详细历史记录
        self.filter_history.append({
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "search_names": search_names,
            "found_files": found_files,  # [(target_filename, original_file_path), ...]
            "not_found_names": [name_from_input for name_from_input in search_names if name_from_input not in found_names_set]
        })

        progress_dialog.close()

        # 修正：在生成not_found_names列表时，也要确保名称是小写的
        not_found_names = [name_from_input for name_from_input in search_names if name_from_input not in found_names_set]

        self.result_window = QWidget()
        self.result_window.setWindowTitle("筛选结果")
        self.result_window.setMinimumSize(600, 400)
        self.result_window.setStyleSheet("""
            QWidget {
                background-color: white;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QTextEdit {
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 8px;
                font-size: 14px;
            }
        """)

        layout = QVBoxLayout(self.result_window)
        
        # 创建滚动区域
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        
        # 创建文本显示区域
        text_widget = QTextEdit()
        text_widget.setReadOnly(True)
        
        # 构建结果文本
        result_parts = []
        if found_files:
            result_parts.append(f"找到的图片: (共 {len(found_files)} 个文件)")
            # 计算最长的文件名长度
            max_filename_length = max(len(filename) for filename, _ in found_files)
            # 格式化显示
            for target_filename, source_path in found_files:
                # 统一使用正斜杠作为路径分隔符
                normalized_path = source_path.replace('\\', '/')
                # 使用固定宽度格式化文件名
                formatted_filename = target_filename.ljust(max_filename_length)
                # 只显示文件名，不重复显示
                result_parts.append(f"{formatted_filename} (来源: {os.path.dirname(normalized_path)})")
        if not_found_names:
            result_parts.append(f"\n未找到的图片名称: (共 {len(not_found_names)} 个)")
            result_parts.extend(not_found_names)
        if error_files:
            result_parts.append(f"\n处理失败的文件: (共 {len(error_files)} 个)")
            result_parts.extend(error_files)
        
        result_text = "\n".join(result_parts)
        text_widget.setText(result_text)
        scroll_layout.addWidget(text_widget)
        
        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)

        # 添加导出按钮
        export_button = QPushButton("导出未找到名称为表格")
        export_button.setToolTip("点击将未找到的名称导出到Excel表格中")
        export_button.clicked.connect(lambda: self.export_not_found_to_excel(not_found_names, output_folder))
        layout.addWidget(export_button)

        # 设置窗口模态
        self.result_window.setWindowModality(Qt.WindowModality.ApplicationModal)
        self.result_window.show()

    def go_to_rename(self):
        self._was_maximized = self.isMaximized()
        self.hide()
        import name
        if self.rename_window is None:
            self.rename_window = name.RenameWindow(self)
        rename_window = self.rename_window
        rename_window._was_maximized = self._was_maximized
        if self._was_maximized:
            rename_window.showMaximized()
        else:
            rename_window.showNormal()

    def show_settings(self):
        dialog = SettingsDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.settings['operation'] = 'copy' if dialog.copy_radio.isChecked() else 'move'
            self.settings['search_subfolders'] = dialog.search_subfolders.isChecked()
            self.settings['add_suffix'] = dialog.add_suffix.isChecked()
            # 保存设置到文件
            save_soso_settings(self.settings)
            self.update_settings_desc_label()

    def show_history(self):
        from history import HistoryWindow
        self.history_window = HistoryWindow(self.filter_history)
        self.history_window.show()

    def eventFilter(self, obj, event):
        # 拦截行号列表的滚轮事件，防止用户独立滚动它
        if obj is self.line_number_list and event.type() == QEvent.Type.Wheel:
            return True  # 事件已处理，不再向下传递

        # 处理文本输入框的粘贴事件
        if obj is self.name_input_entry and event.type() == QEvent.Type.KeyPress:
            if event.key() == Qt.Key.Key_V and event.modifiers() == Qt.KeyboardModifier.ControlModifier:
                # 获取剪贴板内容
                clipboard = QApplication.clipboard()
                text = clipboard.text()
                if text:
                    # 清理粘贴的文本
                    cleaned_text = self.clean_pasted_text(text)
                    # 插入清理后的文本
                    cursor = self.name_input_entry.textCursor()
                    cursor.insertText(cleaned_text)
                    return True  # 阻止默认粘贴行为

        return super().eventFilter(obj, event)
        
    def clean_pasted_text(self, text):
        """清理粘贴文本中的隐藏字符和多余空行（包括全空格/制表符行），去除首尾所有空行"""
        # 按行分割
        lines = text.splitlines()
        cleaned_lines = []
        for line in lines:
            # 移除常见的隐藏字符：零宽空格(U+200B)、零宽不换行空格(U+FEFF)、不间断空格(U+00A0)等
            line = re.sub(r'[\u200B\u200C\u200D\uFEFF\u00A0\u202A-\u202E\u2060\u180E\u200E\u200F]', '', line)
            # 移除行首尾的所有空白字符（包括制表符、全角空格等）
            line = line.strip()
            # 只添加真正有内容的行（过滤掉空行和只包含空白字符的行）
            if line:
                cleaned_lines.append(line)
        # 合并为文本，使用换行符连接
        return '\n'.join(cleaned_lines)

    def on_text_changed(self):
        """只更新行号和滚动条同步，不再自动清理文本"""
        self.update_line_numbers()
        self.line_number_list.verticalScrollBar().setValue(self.name_input_entry.verticalScrollBar().value())

    def check_for_updates(self):
        """检查更新"""
        try:
            # 获取当前文件所在目录
            current_dir = os.path.dirname(os.path.abspath(__file__))
            # 将当前目录添加到系统路径
            if current_dir not in sys.path:
                sys.path.append(current_dir)
            # 导入Internet模块
            from game import check_update
            check_update(self)
        except Exception as e:
            QMessageBox.critical(self, "错误", f"检查更新时发生错误：{str(e)}")

    def update_line_numbers(self):
        """更新行数列表并同步滚动"""
        text = self.name_input_entry.toPlainText()
        line_count = text.count('\n') + 1
        
        # 如果最后一行是空文本，并且总行数大于1，则行数不加1
        if text.endswith('\n'):
             pass # QT的toPlainText在末尾有换行时，count('\n')会少一个，所以这里逻辑上是对的
        
        # 简单的行号生成
        line_numbers_text = '\n'.join(map(str, range(1, line_count + 1)))

        # 关键：先保存当前滚动值
        current_scroll_value = self.name_input_entry.verticalScrollBar().value()

        # 更新行号文本
        self.line_number_list.setText(line_numbers_text)
        
        # 强制UI刷新以确保滚动条范围更新
        QApplication.processEvents()

        # 恢复滚动条位置
        self.name_input_entry.verticalScrollBar().setValue(current_scroll_value)
        # 再次同步一次，确保万无一失
        self.line_number_list.verticalScrollBar().setValue(current_scroll_value)

    def showEvent(self, event):
        super().showEvent(event)
        self.resize(self.size())
        self.updateGeometry()

    def undo_filter(self):
        """撤销上一次筛选操作"""
        # 只撤销最新的 current_operations 类型历史（即文件操作历史）
        # 详细历史记录（带 timestamp 的 dict）不做撤销
        # 先查找最后一个 current_operations 类型的历史
        for i in range(len(self.filter_history) - 1, -1, -1):
            record = self.filter_history[i]
            if isinstance(record, list):  # 旧的 current_operations 结构
                last_operations = self.filter_history.pop(i)
                break
        else:
            QMessageBox.information(self, "提示", "没有可撤销的筛选操作！")
            return

        success_count = 0
        error_count = 0
        errors = []

        # 执行撤销操作
        for original_path, target_path, operation in reversed(last_operations):
            try:
                if os.path.exists(target_path):
                    if operation == 'copy':
                        os.remove(target_path)
                    else:  # move
                        shutil.move(target_path, original_path)
                    success_count += 1
            except Exception as e:
                error_count += 1
                errors.append(f"撤销文件 {os.path.basename(target_path)} 失败: {str(e)}")

        # 显示结果
        if error_count == 0:
            QMessageBox.information(self, "成功", f"成功撤销 {success_count} 个文件的操作！")
        else:
            error_msg = f"成功撤销 {success_count} 个文件，失败 {error_count} 个文件。\n\n"
            error_msg += "错误详情：\n" + "\n".join(errors[:10])
            if len(errors) > 10:
                error_msg += f"\n... 还有 {len(errors) - 10} 个错误"
            QMessageBox.warning(self, "部分成功", error_msg)

    def closeEvent(self, event):
        print("[DEBUG] MainWindow closeEvent triggered")
        super().closeEvent(event)

    def update_settings_desc_label(self):
        """更新右侧设置描述标签"""
        op = self.settings.get('operation', 'copy')
        op_str = '复制文件' if op == 'copy' else '移动文件'
        search_sub = self.settings.get('search_subfolders', False)
        search_str = '启动搜索子文件夹' if search_sub else '不搜索子文件夹'
        desc = f"操作方式：{op_str}，搜索选项：{search_str}"
        self.settings_desc_label.setText(desc)

# 定义类后才能实例化
class FilterWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self._was_maximized = False  # 记录最大化状态
        self.setWindowTitle("文件筛选工具")
        self.setMinimumSize(800, 600)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)  # 关键：窗口自适应
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QLineEdit, QTextEdit {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
                font-size: 14px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            QRadioButton {
                font-size: 14px;
                color: #333;
                padding: 5px;
            }
            QRadioButton::indicator {
                width: 18px;
                height: 18px;
            }
        """)

        # 创建主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 源文件夹选择
        source_layout = QHBoxLayout()
        self.source_entry = QLineEdit()
        self.source_entry.setPlaceholderText("选择源文件夹...")
        source_btn = QPushButton("选择源文件夹")
        source_btn.clicked.connect(self.select_source_folder)
        source_layout.addWidget(QLabel("源文件夹:"))
        source_layout.addWidget(self.source_entry)
        source_layout.addWidget(source_btn)
        layout.addLayout(source_layout)

        # 目标文件夹选择
        target_layout = QHBoxLayout()
        self.target_entry = QLineEdit()
        self.target_entry.setPlaceholderText("选择目标文件夹...")
        target_btn = QPushButton("选择目标文件夹")
        target_btn.clicked.connect(self.select_target_folder)
        target_layout.addWidget(QLabel("目标文件夹:"))
        target_layout.addWidget(self.target_entry)
        target_layout.addWidget(target_btn)
        layout.addLayout(target_layout)

        # 文件类型选择
        type_layout = QVBoxLayout()
        type_label = QLabel("选择文件类型:")
        type_layout.addWidget(type_label)

        # 创建单选按钮组
        self.type_group = QButtonGroup(self)
        self.type_all = QRadioButton("所有文件")
        self.type_image = QRadioButton("图片文件")
        self.type_video = QRadioButton("视频文件")
        self.type_document = QRadioButton("文档文件")
        
        # 设置默认选中所有文件
        self.type_all.setChecked(True)
        
        # 添加单选按钮到组
        self.type_group.addButton(self.type_all)
        self.type_group.addButton(self.type_image)
        self.type_group.addButton(self.type_video)
        self.type_group.addButton(self.type_document)
        
        # 添加单选按钮到布局
        type_layout.addWidget(self.type_all)
        type_layout.addWidget(self.type_image)
        type_layout.addWidget(self.type_video)
        type_layout.addWidget(self.type_document)
        layout.addLayout(type_layout)

        # 文件列表显示
        layout.addWidget(QLabel("文件列表:"))
        self.file_list = QTextEdit()
        self.file_list.setReadOnly(True)
        self.file_list.setMinimumHeight(200)
        layout.addWidget(self.file_list)

        # 操作按钮
        button_layout = QHBoxLayout()
        
        # 刷新按钮
        refresh_btn = QPushButton("刷新文件列表")
        refresh_btn.clicked.connect(self.refresh_file_list)
        button_layout.addWidget(refresh_btn)
        
        # 设置按钮
        settings_btn = QPushButton("设置")
        settings_btn.clicked.connect(self.show_settings)
        button_layout.addWidget(settings_btn)
        
        # 执行按钮
        process_btn = QPushButton("执行操作")
        process_btn.clicked.connect(self.process_files)
        button_layout.addWidget(process_btn)
        
        # 返回按钮
        back_btn = QPushButton("返回主界面")
        back_btn.clicked.connect(self.go_to_main)
        button_layout.addWidget(back_btn)
        
        layout.addLayout(button_layout)

        # 初始化设置
        self.settings = load_soso_settings() # 从文件加载设置
        
        # 初始化文件列表
        self.current_files = []
        self.processed_files = set()  # 用于跟踪已处理的文件

    def select_source_folder(self):
        folder_path = QFileDialog.getExistingDirectory(self, "选择源文件夹", 
                                                     self.source_entry.text())
        if folder_path:
            self.source_entry.setText(folder_path)
            self.refresh_file_list()

    def select_target_folder(self):
        folder_path = QFileDialog.getExistingDirectory(self, "选择目标文件夹", 
                                                     self.target_entry.text())
        if folder_path:
            self.target_entry.setText(folder_path)

    def show_settings(self):
        dialog = SettingsDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.settings['operation'] = 'copy' if dialog.copy_radio.isChecked() else 'move'
            self.settings['search_subfolders'] = dialog.search_subfolders.isChecked()
            self.settings['add_suffix'] = dialog.add_suffix.isChecked()
            # 保存设置到文件
            save_soso_settings(self.settings)

    def get_file_extension(self, filename):
        return os.path.splitext(filename)[1].lower()

    def is_image_file(self, filename):
        return self.get_file_extension(filename) in ('.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp')

    def is_video_file(self, filename):
        return self.get_file_extension(filename) in ('.mp4', '.avi', '.mov', '.wmv', '.flv', '.mkv')

    def is_document_file(self, filename):
        return self.get_file_extension(filename) in ('.pdf', '.doc', '.docx', '.txt', '.rtf', '.odt')

    def get_all_files(self, folder_path):
        """获取指定文件夹下的所有文件"""
        files = []
        if self.settings['search_subfolders']:
            # 搜索子文件夹
            for root, _, filenames in os.walk(folder_path):
                for filename in filenames:
                    full_path = os.path.join(root, filename)
                    # 只处理文件，不处理目录
                    if os.path.isfile(full_path):
                        rel_path = os.path.relpath(full_path, folder_path)
                        files.append((rel_path, full_path))
        else:
            # 只搜索当前文件夹
            for filename in os.listdir(folder_path):
                full_path = os.path.join(folder_path, filename)
                # 只处理文件，不处理目录
                if os.path.isfile(full_path):
                    files.append((filename, full_path))
        return files

    def filter_files(self, files):
        """根据选择的文件类型筛选文件"""
        if self.type_all.isChecked():
            return files
        elif self.type_image.isChecked():
            return [(rel_path, full_path) for rel_path, full_path in files 
                   if self.is_image_file(rel_path)]
        elif self.type_video.isChecked():
            return [(rel_path, full_path) for rel_path, full_path in files 
                   if self.is_video_file(rel_path)]
        else:  # 文档文件
            return [(rel_path, full_path) for rel_path, full_path in files 
                   if self.is_document_file(rel_path)]

    def refresh_file_list(self):
        """刷新文件列表"""
        source_folder = self.source_entry.text()
        if not source_folder:
            QMessageBox.critical(self, "错误", "请先选择源文件夹！")
            return

        if not os.path.exists(source_folder):
            QMessageBox.critical(self, "错误", "源文件夹不存在！")
            return

        # 获取所有文件
        all_files = self.get_all_files(source_folder)
        
        # 根据文件类型筛选
        filtered_files = self.filter_files(all_files)
        
        # 过滤掉已处理的文件
        self.current_files = [(rel_path, full_path) for rel_path, full_path in filtered_files 
                            if full_path not in self.processed_files]
        
        # 更新文件列表显示
        self.update_file_list_display()

    def update_file_list_display(self):
        """更新文件列表显示"""
        self.file_list.clear()
        if not self.current_files:
            self.file_list.append("没有找到符合条件的文件")
            return

        # 显示文件列表
        for i, (rel_path, _) in enumerate(self.current_files, 1):
            self.file_list.append(f"{i}. {rel_path}")

    def process_files(self):
        """处理文件"""
        source_folder = self.source_entry.text()
        target_folder = self.target_entry.text()

        if not source_folder or not target_folder:
            QMessageBox.critical(self, "错误", "请选择源文件夹和目标文件夹！")
            return

        if not os.path.exists(source_folder):
            QMessageBox.critical(self, "错误", "源文件夹不存在！")
            return

        if not os.path.exists(target_folder):
            try:
                os.makedirs(target_folder)
            except OSError as e:
                QMessageBox.critical(self, "错误", f"创建目标文件夹失败：{str(e)}")
                return

        if not self.current_files:
            QMessageBox.information(self, "提示", "没有需要处理的文件！")
            return

        # 执行操作
        success_count = 0
        error_count = 0
        error_messages = []

        for rel_path, full_path in self.current_files:
            try:
                # 保持相对路径结构
                target_path = os.path.join(target_folder, rel_path)
                
                # 确保目标文件夹存在
                target_dir = os.path.dirname(target_path);
                if not os.path.exists(target_dir):
                    os.makedirs(target_dir)

                if self.settings['operation'] == 'copy':
                    shutil.copy2(full_path, target_path)
                else:  # move
                    shutil.move(full_path, target_path)
                
                # 标记文件为已处理
                self.processed_files.add(full_path)
                success_count += 1
            except Exception as e:
                error_count += 1
                error_messages.append(f"处理文件 {rel_path} 时出错：{str(e)}")

        # 更新文件列表
        self.refresh_file_list()

        # 显示结果
        if error_count == 0:
            QMessageBox.information(self, "成功", f"成功{self.settings['operation']} {success_count} 个文件！")
        else:
            error_msg = f"成功{self.settings['operation']} {success_count} 个文件，失败 {error_count} 个文件。\n\n"
            error_msg += "错误详情：\n" + "\n".join(error_messages[:10])
            if len(error_messages) > 10:
                error_msg += f"\n... 还有 {len(error_messages) - 10} 个错误"
            QMessageBox.warning(self, "部分成功", error_msg)

    def go_to_main(self):
        self._was_maximized = self.isMaximized()
        self.hide()
        import name
        name.rename_window._was_maximized = self._was_maximized
        if self._was_maximized:
            name.rename_window.showMaximized()
        else:
            name.rename_window.showNormal()

def create_main_window():
    return MainWindow()

def main():
    multiprocessing.freeze_support()
    app = QApplication(sys.argv)
    # 这里可以加密码验证逻辑，如果需要
    global main_window, filter_window
    main_window = MainWindow()
    filter_window = FilterWindow()
    main_window.show()
    sys.exit(app.exec())
    


if __name__ == "__main__":
    app = QApplication.instance() or QApplication(sys.argv)
    main()














