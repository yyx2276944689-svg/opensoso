from flask import Flask, jsonify, send_file, request
import os
import json
import logging

# 配置日志
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# 服务器配置
SERVER_FOLDER = "C:/opensoso"
VERSION_FILE = os.path.join(SERVER_FOLDER, "version.json")
UPDATE_FILE = os.path.join(SERVER_FOLDER, "update.zip")

@app.route('/version')
def get_version():
    """返回版本信息"""
    try:
        logger.info(f"Received version request from {request.remote_addr}")
        
        if not os.path.exists(SERVER_FOLDER):
            logger.error(f"Server folder {SERVER_FOLDER} does not exist")
            return jsonify({"error": "Server folder not found"}), 500
            
        if not os.path.exists(VERSION_FILE):
            logger.error(f"Version file {VERSION_FILE} does not exist")
            return jsonify({
                "version": "1.0.0",
                "url": f"http://{request.host}/download",
                "notes": "初始版本"
            })
            
        with open(VERSION_FILE, 'r', encoding='utf-8') as f:
            version_info = json.load(f)
            version_info['url'] = f"http://{request.host}/download"
            logger.info(f"Returning version info: {version_info}")
            return jsonify(version_info)
            
    except Exception as e:
        logger.error(f"Error in get_version: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/download')
def download_update():
    """提供更新文件下载"""
    try:
        logger.info(f"Received download request from {request.remote_addr}")
        
        if not os.path.exists(UPDATE_FILE):
            logger.error(f"Update file {UPDATE_FILE} does not exist")
            return jsonify({"error": "更新文件不存在"}), 404
            
        logger.info(f"Sending update file: {UPDATE_FILE}")
        return send_file(
            UPDATE_FILE,
            as_attachment=True,
            download_name="update.zip",
            mimetype='application/zip'
        )
    except Exception as e:
        logger.error(f"Error in download_update: {str(e)}", exc_info=True)
        return jsonify({"error": str(e)}), 500

@app.route('/test')
def test_connection():
    """测试连接"""
    return jsonify({"status": "ok", "message": "Server is running"})

if __name__ == '__main__':
    # 确保服务器文件夹存在
    if not os.path.exists(SERVER_FOLDER):
        logger.info(f"Creating server folder: {SERVER_FOLDER}")
        os.makedirs(SERVER_FOLDER)
    
    # 启动服务器
    logger.info("Starting server...")
    app.run(host='0.0.0.0', port=5000, debug=True) 