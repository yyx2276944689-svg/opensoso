from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                            QPushButton, QLineEdit, QTextEdit, QLabel, 
                            QFileDialog, QMessageBox, QRadioButton, QButtonGroup,
                            QDialog, QCheckBox, QScrollArea, QApplication, QSizePolicy)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QIcon, QPixmap, QFont
import os
import shutil
from datetime import datetime

class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("设置")
        self.setFixedSize(400, 300)
        self.setStyleSheet("""
            QDialog {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QCheckBox {
                font-size: 14px;
                color: #333;
                padding: 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QToolTip {
                background-color: #333;
                color: white;
                border: none;
                padding: 5px;
                border-radius: 3px;
                show-delay: 1000ms;
            }
        """)

        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 操作方式选择
        operation_layout = QVBoxLayout()
        operation_label = QLabel("操作方式:")
        operation_layout.addWidget(operation_label)

        self.operation_group = QButtonGroup(self)
        self.copy_radio = QRadioButton("复制文件")
        self.move_radio = QRadioButton("移动文件")
        
        # 根据当前设置设置默认选项
        if parent.settings['operation'] == 'copy':
            self.copy_radio.setChecked(True)
        else:
            self.move_radio.setChecked(True)

        self.operation_group.addButton(self.copy_radio)
        self.operation_group.addButton(self.move_radio)

        operation_layout.addWidget(self.copy_radio)
        operation_layout.addWidget(self.move_radio)
        layout.addLayout(operation_layout)

        # 搜索选项
        search_layout = QVBoxLayout()
        search_label = QLabel("搜索选项:")
        search_layout.addWidget(search_label)

        self.search_subfolders = QCheckBox("搜索子文件夹")
        # 根据当前设置设置默认选项
        self.search_subfolders.setChecked(parent.settings['search_subfolders'])
        search_layout.addWidget(self.search_subfolders)
        layout.addLayout(search_layout)

        # 确定按钮
        ok_button = QPushButton("确定")
        ok_button.clicked.connect(self.accept)
        layout.addWidget(ok_button)

class RenameWindow(QMainWindow):
    def __init__(self, main_window):
        super().__init__()
        self._was_maximized = False  # 记录最大化状态
        self.main_window = main_window  # 正确保存主窗口引用
        self.setWindowTitle("批量重命名工具")
        self.setMinimumSize(800, 600)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        
        # 初始化设置
        self.settings = {
            'operation': 'copy',  # 'copy' 或 'move'
            'search_subfolders': False  # 默认不搜索子文件夹
        }
        
        # 初始化重命名历史记录
        self.rename_history = []
        
        # 设置窗口图标
        icon_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QLineEdit, QTextEdit {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
                font-size: 14px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            QRadioButton {
                font-size: 14px;
                color: #333;
                padding: 5px;
            }
            QRadioButton::indicator {
                width: 18px;
                height: 18px;
            }
            QToolTip {
                background-color: #333;
                color: white;
                border: none;
                padding: 5px;
                border-radius: 3px;
                show-delay: 1000ms;
            }
        """)

        # 创建主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 图片文件夹选择
        folder_layout = QHBoxLayout()
        self.folder_entry = QLineEdit()
        self.folder_entry.setPlaceholderText("选择图片文件夹...")
        folder_btn = QPushButton("选择文件夹")
        folder_btn.setToolTip("点击选择包含图片的文件夹")
        folder_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QToolTip {
                background-color: #333;
                color: white;
                border: none;
                padding: 5px;
                border-radius: 3px;
            }
        """)
        folder_btn.clicked.connect(self.select_folder)
        folder_layout.addWidget(QLabel("图片文件夹:"))
        folder_layout.addWidget(self.folder_entry)
        folder_layout.addWidget(folder_btn)
        layout.addLayout(folder_layout)

        # 排序选项
        sort_layout = QVBoxLayout()
        sort_label = QLabel("选择排序方式:")
        sort_layout.addWidget(sort_label)

        # 创建单选按钮组
        self.sort_group = QButtonGroup(self)
        self.sort_by_time = QRadioButton("按修改时间排序")
        self.sort_by_name = QRadioButton("按名称排序")
        self.sort_by_size = QRadioButton("按大小排序")
        
        # 设置默认选中按名称排序
        self.sort_by_name.setChecked(True)
        
        # 添加单选按钮到组
        self.sort_group.addButton(self.sort_by_time)
        self.sort_group.addButton(self.sort_by_name)
        self.sort_group.addButton(self.sort_by_size)
        
        # 添加单选按钮到布局
        sort_layout.addWidget(self.sort_by_time)
        sort_layout.addWidget(self.sort_by_name)
        sort_layout.addWidget(self.sort_by_size)

        # 排序方向选项（适用于所有排序方式）
        direction_layout = QHBoxLayout()
        direction_label = QLabel("排序方向:")
        direction_layout.addWidget(direction_label)
        
        self.direction_group = QButtonGroup(self)
        self.ascending = QRadioButton("升序")
        self.descending = QRadioButton("降序")
        self.ascending.setChecked(True)  # 默认升序
        
        self.direction_group.addButton(self.ascending)
        self.direction_group.addButton(self.descending)
        
        direction_layout.addWidget(self.ascending)
        direction_layout.addWidget(self.descending)
        direction_layout.addStretch()
        
        # 时间排序的特殊说明
        time_note_layout = QHBoxLayout()
        self.time_note = QLabel("（时间排序：升序=从早到晚，降序=从晚到早）")
        self.time_note.setStyleSheet("color: #666; font-size: 12px;")
        time_note_layout.addWidget(self.time_note)
        time_note_layout.addStretch()
        
        # 将排序方向选项添加到布局
        sort_layout.addLayout(direction_layout)
        sort_layout.addLayout(time_note_layout)
        
        layout.addLayout(sort_layout)

        # 名称输入区域
        layout.addWidget(QLabel("输入新名称（每行一个名称）:"))
        self.name_input = QTextEdit()
        self.name_input.setPlaceholderText("在此输入新的名称，每行一个...")
        self.name_input.setMinimumHeight(200)
        layout.addWidget(self.name_input)

        # 预览按钮
        preview_btn = QPushButton("预览文件顺序")
        preview_btn.setMinimumHeight(35)
        preview_btn.setToolTip("点击预览文件排序后的顺序")
        preview_btn.clicked.connect(self.preview_file_order)

        # 创建水平布局来放置重命名按钮和撤回按钮
        rename_layout = QHBoxLayout()
        
        # 执行按钮
        rename_btn = QPushButton("执行重命名")
        rename_btn.setMinimumHeight(40)
        rename_btn.setToolTip("点击开始执行批量重命名操作")
        rename_btn.clicked.connect(self.rename_images)
        rename_layout.addWidget(rename_btn)

        # 添加撤回按钮
        undo_btn = QPushButton()
        undo_btn.setObjectName("undoButton")
        icon_path = os.path.join(os.path.dirname(__file__), "testround.png")
        if os.path.exists(icon_path):
            undo_btn.setIcon(QIcon(icon_path))
        undo_btn.setIconSize(QSize(24, 24))
        undo_btn.setFixedSize(32, 32)
        undo_btn.setToolTip("点击撤回上一次的重命名操作")
        undo_btn.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 4px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QToolTip {
                background-color: #333;
                color: white;
                border: none;
                padding: 5px;
                border-radius: 3px;
            }
        """)
        undo_btn.clicked.connect(self.undo_rename)
        rename_layout.addWidget(undo_btn)

        # 创建水平布局来放置预览按钮和重命名按钮组
        button_layout = QHBoxLayout()
        button_layout.addWidget(preview_btn)
        button_layout.addLayout(rename_layout)
        layout.addLayout(button_layout)

        # 返回按钮
        back_btn = QPushButton("返回主界面")
        back_btn.setMinimumHeight(40)
        back_btn.setToolTip("点击返回主程序界面")
        back_btn.clicked.connect(self.go_to_main)
        layout.addWidget(back_btn)

    def showEvent(self, event):
        super().showEvent(event)
        self.resize(self.size())
        self.updateGeometry()

    def select_folder(self):
        folder_path = QFileDialog.getExistingDirectory(self, "选择图片文件夹", 
                                                     self.folder_entry.text())
        if folder_path:
            self.folder_entry.setText(folder_path)

    def get_all_files(self, folder_path):
        files = []
        if self.settings['search_subfolders']:
            for root, _, filenames in os.walk(folder_path):
                for filename in filenames:
                    full_path = os.path.join(root, filename)
                    # 只处理文件，不处理目录
                    if os.path.isfile(full_path):
                        rel_path = os.path.relpath(full_path, folder_path)
                        files.append((rel_path, full_path))
        else:
            for filename in os.listdir(folder_path):
                full_path = os.path.join(folder_path, filename)
                # 只处理文件，不处理目录
                if os.path.isfile(full_path):
                    files.append((filename, full_path))
        return files

    def get_sorted_files(self, folder_path):
        """根据选择的排序方式获取排序后的文件列表"""
        # 获取所有图片文件
        image_files = self.get_all_files(folder_path)
        
        if not image_files:
            return []
        
        # 确定是否为降序排序
        reverse_order = self.descending.isChecked()
        
        try:
            # 根据选择的排序方式排序
            if self.sort_by_time.isChecked():
                # 按修改时间排序
                image_files.sort(key=lambda x: os.path.getmtime(x[1]), reverse=reverse_order)
            elif self.sort_by_name.isChecked():
                # 按名称排序（忽略大小写）
                image_files.sort(key=lambda x: x[0].lower(), reverse=reverse_order)
            else:  # 按大小排序
                image_files.sort(key=lambda x: os.path.getsize(x[1]), reverse=reverse_order)
        except OSError as e:
            QMessageBox.critical(self, "错误", f"排序文件时出错：{str(e)}")
            return []
            
        return image_files

    def preview_file_order(self):
        """预览文件排序顺序"""
        folder_path = self.folder_entry.text()
        if not folder_path:
            QMessageBox.critical(self, "错误", "请先选择图片文件夹！")
            return

        if not os.path.exists(folder_path):
            QMessageBox.critical(self, "错误", "所选文件夹不存在！")
            return

        # 获取排序后的图片文件列表
        image_files = self.get_sorted_files(folder_path)

        if not image_files:
            QMessageBox.information(self, "提示", "所选文件夹中没有图片文件！")
            return

        # 创建预览对话框
        preview_dialog = QDialog(self)
        preview_dialog.setWindowTitle("文件排序预览")
        preview_dialog.setMinimumSize(600, 400)
        
        layout = QVBoxLayout(preview_dialog)
        
        # 排序方式说明
        sort_method = ""
        if self.sort_by_time.isChecked():
            direction = "从早到晚" if self.ascending.isChecked() else "从晚到早"
            sort_method = f"按修改时间排序 - {direction}"
        elif self.sort_by_name.isChecked():
            direction = "升序" if self.ascending.isChecked() else "降序"
            sort_method = f"按名称排序 - {direction}"
        else:
            direction = "从小到大" if self.ascending.isChecked() else "从大到小"
            sort_method = f"按文件大小排序 - {direction}"
        
        info_label = QLabel(f"排序方式：{sort_method}\n共找到 {len(image_files)} 个图片文件")
        info_label.setStyleSheet("font-weight: bold; padding: 10px;")
        layout.addWidget(info_label)
        
        # 文件列表
        scroll_area = QScrollArea()
        scroll_widget = QWidget()
        scroll_layout = QVBoxLayout(scroll_widget)
        scroll_layout.setSpacing(2)  # 设置行间距
        scroll_layout.setContentsMargins(10, 10, 10, 10)  # 设置边距
        
        # 设置滚动区域的样式
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
            }
            QScrollBar:vertical {
                border: none;
                background: #f0f0f0;
                width: 12px;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #c0c0c0;
                min-height: 20px;
                border-radius: 6px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)
        
        for i, (rel_path, full_path) in enumerate(image_files[:50]):  # 只显示前50个文件
            try:
                # 获取文件信息
                stat = os.stat(full_path)
                size = stat.st_size
                mtime = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
                
                # 创建文件信息容器
                file_container = QWidget()
                file_layout = QHBoxLayout(file_container)
                file_layout.setContentsMargins(5, 2, 5, 2)
                
                # 序号标签
                index_label = QLabel(f"{i+1:3d}.")
                index_label.setStyleSheet("color: #666; min-width: 40px;")
                file_layout.addWidget(index_label)
                
                # 文件名标签
                name_label = QLabel(rel_path)
                name_label.setStyleSheet("font-weight: bold;")
                name_label.setWordWrap(True)  # 允许文本换行
                file_layout.addWidget(name_label, 1)  # 1表示拉伸因子
                
                # 文件信息标签
                info_label = QLabel(f"大小: {size:,} 字节, 修改时间: {mtime}")
                info_label.setStyleSheet("color: #666;")
                info_label.setWordWrap(True)  # 允许文本换行
                file_layout.addWidget(info_label)
                
                scroll_layout.addWidget(file_container)
            except OSError:
                file_container = QWidget()
                file_layout = QHBoxLayout(file_container)
                file_layout.setContentsMargins(5, 2, 5, 2)
                
                error_label = QLabel(f"{i+1:3d}. {rel_path} (无法获取文件信息)")
                error_label.setStyleSheet("color: red;")
                error_label.setWordWrap(True)  # 允许文本换行
                file_layout.addWidget(error_label)
                
                scroll_layout.addWidget(file_container)
        
        if len(image_files) > 50:
            more_label = QLabel(f"... 还有 {len(image_files) - 50} 个文件未显示")
            more_label.setStyleSheet("padding: 10px; font-style: italic; color: #666;")
            scroll_layout.addWidget(more_label)
        
        scroll_widget.setLayout(scroll_layout)
        scroll_area.setWidget(scroll_widget)
        scroll_area.setWidgetResizable(True)  # 允许内容调整大小
        layout.addWidget(scroll_area)
        
        # 关闭按钮
        close_btn = QPushButton("关闭")
        close_btn.setToolTip("点击关闭预览窗口")
        close_btn.clicked.connect(preview_dialog.accept)
        layout.addWidget(close_btn)
        
        preview_dialog.exec()

    def rename_images(self):
        """执行批量重命名"""
        folder_path = self.folder_entry.text()
        if not folder_path:
            QMessageBox.critical(self, "错误", "请选择图片文件夹！")
            return

        if not os.path.exists(folder_path):
            QMessageBox.critical(self, "错误", "所选文件夹不存在！")
            return

        new_names = self.name_input.toPlainText().strip().split('\n')
        new_names = [name.strip() for name in new_names if name.strip()]

        if not new_names:
            QMessageBox.critical(self, "错误", "请输入新的名称！")
            return

        # 获取排序后的图片文件列表
        image_files = self.get_sorted_files(folder_path)

        if not image_files:
            QMessageBox.critical(self, "错误", "所选文件夹中没有图片文件！")
            return

        # 检查名称数量
        if len(new_names) < len(image_files):
            reply = QMessageBox.question(
                self, "确认", 
                f"新名称数量（{len(new_names)}）少于图片数量（{len(image_files)}），\n"
                f"将只重命名前 {len(new_names)} 个文件。\n\n是否继续？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        # 执行重命名
        renamed_count = 0
        errors = []
        used_names = set()  # 用于跟踪已使用的文件名
        current_rename_operations = []  # 记录当前重命名操作

        # 限制重命名数量
        files_to_rename = min(len(image_files), len(new_names))

        for i in range(files_to_rename):
            old_rel_path, old_full_path = image_files[i]
            new_base_name = new_names[i]
            
            # 获取原文件扩展名
            file_ext = os.path.splitext(old_rel_path)[1]
            
            # 处理文件名冲突
            counter = 1
            while True:
                if counter == 1:
                    final_name = f"{new_base_name}{file_ext}"
                else:
                    final_name = f"{new_base_name}_{counter}{file_ext}"
                
                new_full_path = os.path.join(folder_path, final_name)
                
                # 检查文件名是否已被使用或已存在
                if final_name not in used_names and not os.path.exists(new_full_path):
                    break
                    
                counter += 1
                if counter > 1000:  # 防止无限循环
                    errors.append(f"无法为文件 {old_rel_path} 生成唯一名称")
                    break
            
            if counter <= 1000:
                try:
                    # 执行重命名
                    os.rename(old_full_path, new_full_path)
                    used_names.add(final_name)
                    renamed_count += 1
                    # 记录重命名操作
                    current_rename_operations.append((old_full_path, new_full_path))
                except OSError as e:
                    errors.append(f"重命名 {old_rel_path} 失败: {str(e)}")

        # 如果有成功的重命名操作，添加到历史记录
        if current_rename_operations:
            self.rename_history.append(current_rename_operations)

        # 显示结果
        if errors:
            error_msg = f"成功重命名 {renamed_count} 个文件。\n\n以下文件重命名失败：\n"
            error_msg += "\n".join(errors[:10])  # 只显示前10个错误
            if len(errors) > 10:
                error_msg += f"\n... 还有 {len(errors) - 10} 个错误"
            QMessageBox.warning(self, "部分成功", error_msg)
        else:
            QMessageBox.information(self, "成功", f"成功重命名 {renamed_count} 个文件！")

    def undo_rename(self):
        """撤回上一次重命名操作"""
        if not self.rename_history:
            QMessageBox.information(self, "提示", "没有可撤回的重命名操作！")
            return

        # 获取最后一次重命名操作
        last_operations = self.rename_history.pop()
        success_count = 0
        error_count = 0
        errors = []

        # 执行撤回操作
        for old_path, new_path in reversed(last_operations):
            try:
                if os.path.exists(new_path):
                    os.rename(new_path, old_path)
                    success_count += 1
            except OSError as e:
                error_count += 1
                errors.append(f"撤回文件 {os.path.basename(new_path)} 失败: {str(e)}")

        # 显示结果
        if error_count == 0:
            QMessageBox.information(self, "成功", f"成功撤回 {success_count} 个文件的重命名操作！")
        else:
            error_msg = f"成功撤回 {success_count} 个文件，失败 {error_count} 个文件。\n\n"
            error_msg += "错误详情：\n" + "\n".join(errors[:10])
            if len(errors) > 10:
                error_msg += f"\n... 还有 {len(errors) - 10} 个错误"
            QMessageBox.warning(self, "部分成功", error_msg)

    def go_to_main(self):
        self._was_maximized = self.isMaximized()
        self.hide()
        if self.main_window is not None:
            self.main_window._was_maximized = self._was_maximized
            if self._was_maximized:
                self.main_window.showMaximized()
            else:
                self.main_window.showNormal()
        else:
            QMessageBox.information(self, "提示", "无法返回主界面，请重新启动程序。")
