import os

def _process_single_file_for_matching(file_path, search_names):
    filename = os.path.basename(file_path)
    for search_name in search_names:
        if '-' in search_name and search_name.split('-')[-1].isdigit():
            if search_name.lower() == filename.lower():
                return file_path, search_name
        else:
            if search_name.lower() in filename.lower():
                return file_path, search_name
    return None 