#opensoso

import sys
import os
import json
import base64
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QPushButton, QLineEdit, QLabel, 
                            QMessageBox, QCheckBox)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont, QIcon

def load_password():
    if os.path.exists("password.json"):
        with open("password.json", "r", encoding="utf-8") as f:
            try:
                data = json.load(f)
                if data.get("password"):
                    data["password"] = base64.b64decode(data["password"]).decode('utf-8')
                return data
            except:
                return {"password": "", "remember": False}
    return {"password": "", "remember": False}

def save_password(password, remember):
    encoded = base64.b64encode(password.encode('utf-8')).decode('utf-8')
    with open("password.json", "w", encoding="utf-8") as f:
        json.dump({"password": encoded, "remember": remember}, f)

class PasswordWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Opensoso 密码验证")
        self.setFixedSize(400, 200)
        
        # 设置按钮窗口图标
        icon_path = os.path.join(os.path.dirname(__file__), "logo.png")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
            
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QLineEdit {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: white;
                font-size: 14px;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
            QCheckBox {
                font-size: 14px;
                color: #333;
                padding: 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
        """)

        # 创建主窗口部件
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # 密码输入框
        password_layout = QHBoxLayout()
        self.password_entry = QLineEdit()
        self.password_entry.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_entry.setPlaceholderText("请输入密码...")
        self.password_entry.returnPressed.connect(self.verify_password)
        password_layout.addWidget(QLabel("密码:"))
        password_layout.addWidget(self.password_entry)
        layout.addLayout(password_layout)

        # 记住密码选项
        self.remember_checkbox = QCheckBox("记住密码")
        layout.addWidget(self.remember_checkbox)

        # 确定按钮
        ok_button = QPushButton("确定")
        ok_button.setMinimumHeight(40)
        ok_button.clicked.connect(self.verify_password)
        layout.addWidget(ok_button)

        # 加载保存的密码
        saved_password = load_password()
        if saved_password["remember"]:
            self.password_entry.setText(saved_password["password"])
            self.remember_checkbox.setChecked(True)

    def verify_password(self):
        password = self.password_entry.text()
        if password == "12345678910":  
            save_password(password, self.remember_checkbox.isChecked())
            self.hide()
            import soso
            main_window = soso.create_main_window()
            main_window.show()
        else:
            QMessageBox.critical(self, "错误", "密码错误！")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = PasswordWindow()
    window.show()
    sys.exit(app.exec())
